"""Local QR selection only. This module never verifies a bank payment or calls UPI."""
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from core import SafeError


@dataclass(frozen=True)
class PaymentAsset:
    pid: str
    amount: Decimal
    currency: str
    path: Path
    sha256: str
    payee_upi: str
    payee_name: str


class PaymentCatalog:
    def __init__(self, manifest_path='assets/payments/manifest.json'):
        self.path = Path(manifest_path).resolve()
        self.entries = {}
        try:
            data = json.loads(self.path.read_text())
            for row in data['entries']:
                pid = str(row['pid'])
                if pid in self.entries:
                    raise ValueError()
                self.entries[pid] = row
            if not self.entries:
                raise ValueError()
        except (OSError, KeyError, TypeError, ValueError):
            raise SafeError('Payment QR manifest is missing or invalid. No payment instructions can be shown.') from None

    def for_order(self, order):
        try:
            quote = json.loads(order['quote'])
            row = self.entries[quote['pid']]
            if order['quantity'] != 1:
                raise ValueError()
            amount = Decimal(str(row['amount']))
            expected = Decimal(quote['customer_price'])
            if not amount.is_finite() or amount <= 0 or amount != expected:
                raise ValueError()
            if row['currency'] != 'INR' or quote['currency'] != 'INR':
                raise ValueError()
            path = (self.path.parent / row['file']).resolve()
            if path.parent != self.path.parent or path.suffix.lower() != '.png':
                raise ValueError()
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if digest != row['sha256']:
                raise ValueError()
            payload = urlparse(row['payload'])
            fields = parse_qs(payload.query, strict_parsing=True)
            if payload.scheme != 'upi' or payload.netloc != 'pay' or payload.fragment:
                raise ValueError()
            if any(len(fields.get(k, [])) != 1 for k in ('pa', 'pn', 'am', 'cu')):
                raise ValueError()
            if (fields['pa'][0] != row['payee_upi'] or fields['pn'][0] != row['payee_name'] or
                    Decimal(fields['am'][0]) != amount or fields['cu'][0] != 'INR'):
                raise ValueError()
            return PaymentAsset(quote['pid'], amount, 'INR', path, digest,
                                row['payee_upi'], row['payee_name'])
        except (OSError, KeyError, TypeError, ValueError, InvalidOperation):
            raise SafeError('Matching payment QR is unavailable, changed, or has a different amount. Do not pay; contact the admin.') from None
