# PHANTOM Telegram subscription bot

**Manual UPI QR payments, followed by admin verification and separate supplier-order approval.** For Android, follow [the Termux setup guide](TERMUX.md). No Docker, PC, public server or inbound port is required for Telegram polling.

The owner selected live ordering. This package enables the nine corrected PHANTOM rows and sets the deployment template to `DEMO_MODE=false`. **It is not deployed or connected:** reseller and Telegram credentials are blank, and `LIVE_CATALOG_CONFIRMED=false` blocks live startup until you verify the catalog locally. No supplier order or connectivity purchase has been made.

## Your catalog and prices

| PID | Subscription | Customer price | Expected supplier cost |
|---|---|---:|---:|
| 343 | 1 Hour | INR 12.00 | INR 7.00 |
| 344 | 3 Hours | INR 35.00 | INR 15.00 |
| 345 | 6 Hours | INR 60.00 | INR 23.00 |
| 346 | 12 Hours | INR 80.00 | INR 45.00 |
| 347 | 1 Day | INR 90.00 | INR 70.00 |
| 348 | 3 Days | INR 165.00 | INR 120.00 |
| 349 | 7 Days | INR 330.00 | INR 215.00 |
| 350 | 15 Days | INR 450.00 | INR 350.00 |
| 351 | 30 Days | INR 650.00 | INR 449.00 |

Each PHANTOM license records a one-device limit, based on the owner's list. `customer_price` is the selling price and `supplier_cost` is the expected wholesale wallet charge. Customer listings and quotes do not show wholesale costs; admin approval reviews show both totals. Price or device-limit changes expire an existing quote. Device limits are metadata; your app/license system must enforce them.

APKMOD remains disabled with blank values. `stock: null` means unknown, not unlimited. The owner-provided API example has no documented product listing, so the catalog is maintained locally. Compare these settings with your supplier panel before changing `LIVE_CATALOG_CONFIRMED=true` in your private `.env`.

## Prepare and start

Run `bash setup_termux.sh` in Termux; it prepares `.venv-termux`, installs native cryptography and dependencies, creates `.env` only if absent and initializes only a blank `FERNET_KEY`. It does not start the bot or contact the supplier. Full transfer and upgrade commands are in `TERMUX.md`.

Enter a BotFather token, positive numeric `ADMIN_IDS`, optional customer `ALLOWED_USER_IDS`, and **a freshly rotated `PANEL_API_KEY` locally**. Revoke the exposed old key; no key is embedded or recovered from the screenshot. Blank customer access means admins only. Preserve the encryption key and database from an existing installation. The installer never overwrites an existing `.env`, so update its mode settings manually when upgrading.

The selected live configuration is:

```dotenv
DEMO_MODE=false
API_SCHEMA_CONFIRMED=true
LIVE_CATALOG_CONFIRMED=true
CATALOG_PATH=catalog.json
```

The catalog flag above is the setting **after your local verification**; the shipped template deliberately keeps it false. Schema confirmation selects the mapping from your supplied example, not a claim that the live service was tested.

Activate the Termux environment, then run:

```bash
source .venv-termux/bin/activate
python preflight.py
python bot.py
```

Preflight checks configuration and every enabled plan's QR payload amount and PNG checksum offline. It sends no API or Telegram requests and cannot verify credential acceptance, supplier balance, current cost, stock or receipt of payment. Startup connects Telegram polling only; it makes no automatic supplier order or balance request. To try a simulated flow instead, set `DEMO_MODE=true`; the bot then uses clearly marked built-in sample products, disables real QR payments and generates no valid licenses.

## Every purchase needs a separate approval

1. Customer uses `/products`, then `/buy PRODUCT_ID 1` and presses **Request admin approval**. The bot sends the matching cropped QR as an original PNG document, with the exact selling amount and payee in its caption. Payment is marked `awaiting_manual_verification`; no supplier purchase happens.
2. After paying in their own UPI app, the customer sends `/paid ORDER_ID UTR`, **or sends a payment screenshot as a photo/image document** with the exact order ID as caption. With no caption, a screenshot is attached only to that customer's single pending order. Status becomes `customer_reported`, NOT verified. Evidence is encrypted in the local database and sent only to configured admins.
3. Admin checks the actual incoming bank/UPI credit, amount, payee and transaction. A UTR or screenshot alone is not proof. `/verifypayment ORDER_ID` displays a separate **I checked the bank: mark payment verified** button. Pressing it records the admin's manual decision and does not call the supplier.
4. Admin runs `/approve ORDER_ID` to review the customer, PID, quantity, selling total and supplier cost, then presses **Approve supplier order**. Only this separate final confirmation can call the supplier and spend reseller balance.
5. The returned key is encrypted locally and delivered to the original customer's private chat.

This applies to admin self-purchases too. There is no auto-approval or automatic bank/UPI verification, webhook, OCR proof, payment-gateway integration or automatic refund. The bot displays payment instructions; the customer pays directly in their UPI app. Quotes expire after 15 minutes. If a paid quote expires or changes, reconcile it manually before any replacement order and never ask the customer to pay twice. Reported/verified payment orders cannot be casually canceled in the bot. Live quantity is limited to one key because the supplied response contains one `license_key`.

## Cropped QR assets

All nine screenshots were supplied. `assets/payments/qr_343.png` through `qr_351.png` are lossless crops with margins, without phone UI or reconstruction of the QR pattern. Each cropped payload was decoded and compared byte-for-byte with its original, and its embedded amount matches the customer price. The manifest records those checks and image hashes. All encode the owner-provided payee David Samuel / `davidsamuel9342@okhdfcbank`. No replacement screenshot is needed for the current catalog. This confirms encoded instructions, not that a payment will succeed or has been received.

Keep the full `assets/payments/` directory when installing. A changed price without a corresponding validated QR fails closed instead of displaying the wrong amount. The PNG is sent as a document to avoid Telegram photo recompression; customers can download it and scan from their UPI app's gallery. A UPI PIN is entered only in the customer's own payment app, never in the bot.

## Commands

Customer: `/start`, `/id`, `/products [search]`, `/buy PID 1`, `/payment ORDER_ID` (resend an unpaid QR), `/paid ORDER_ID UTR`, screenshot submission, `/orders`, `/keys ORDER_ID`, `/cancel ORDER_ID` (before reporting payment).

Admin: `/balance`, `/pending`, `/verifypayment ORDER_ID`, `/approve ORDER_ID`, `/reject ORDER_ID` (unpaid orders), `/retrydelivery ORDER_ID`. Admins must start the bot so it can notify them. `/balance` is an optional supplier query, not a purchase.

## Supplier contract and uncertain results

The adapter sends a JSON POST to `https://panelstore.shop/api/v1/index.php` with only `key`, `action: "order"`, integer `pid`, `quantity: 1`, and `custom_notes` set to the unique local order reference. It expects `status: "success"`, string `license_key` and `order_code`. Neither price is sent as a charge cap. Balance requests use `key` and `action: "balance"`, and validate `balance`/`currency`.

Supplier costs and stock are not live-verified, and no maximum-charge, supplier idempotency or order-lookup field was documented. Approve only if you accept that pricing risk. A timeout or malformed response may happen after the supplier charged you. Such orders remain `uncertain` or `processing`: investigate the panel using `custom_notes` before doing anything else. Never create a replacement purchase simply because delivery failed.

Durable local claims prevent duplicate callbacks from repeating the same purchase. Supplier orders are not automatically retried. `/keys` and `/retrydelivery` resend only stored keys, without another supplier call. This does not claim exactly-once behavior across the supplier network or exactly-once Telegram delivery.

## Privacy and hosting limits

Keys use Fernet encryption at rest. Keep `.env`, `FERNET_KEY`, `data/` and backups private, and back up the encryption key separately. A wrong key fails startup when encrypted records exist. Do not enable HTTP debug logging: Telegram URLs contain the bot token. Telegram bot chats are not end-to-end encrypted, and protected content does not prevent screenshots.

Run exactly one polling process with persistent local storage. Android can stop Termux; `tmux` and wake locks do not guarantee 24/7 uptime or reboot persistence. Internet access is required. Optional Docker files are for ordinary Linux, not standard Termux.

```bash
python -m pytest -q
python demo_check.py
```

Tests use fake keys and mocked responses, and the offline demo makes no supplier call. Testing was on Linux, not the user's Android device or live supplier account. Sources: the owner's supplier example, [Telegram Bot API](https://core.telegram.org/bots/api), and the official Termux references in the phone guide.
