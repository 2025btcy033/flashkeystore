"""Demo-first storefront core. No supplier mutation is retried automatically."""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import time
import uuid
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib.parse import urlparse

import httpx
from cryptography.fernet import Fernet


class SafeError(Exception):
    """Messages in this exception are intentionally safe to show to users."""


def at(obj, path):
    for key in path.split('.') if path else []:
        obj = obj[key]
    return obj


@dataclass(frozen=True)
class Product:
    pid: str
    name: str
    price: Decimal
    stock: int | None
    currency: str
    customer_price: Decimal | None = None
    device_limit: int | None = None

    @property
    def supplier_cost(self):
        # Preserve the original price attribute for existing integrations and saved quotes.
        return self.price

    @property
    def selling_price(self):
        return self.customer_price if self.customer_price is not None else self.price

    def snapshot(self):
        return {'pid': self.pid, 'name': self.name, 'price': str(self.price),
                'supplier_cost': str(self.supplier_cost), 'customer_price': str(self.selling_price),
                'device_limit': self.device_limit, 'stock': self.stock, 'currency': self.currency}


class Supplier:
    def __init__(self, demo=True, key='', url='https://panelstore.shop/api/v1/index.php',
                 mapping=None, confirmed=False, transport=None, catalog_path='catalog.json',
                 catalog_confirmed=False):
        self.demo, self.key, self.url = demo, key, url
        self.mapping = mapping or {}
        self.transport = transport
        self.catalog_path = Path(catalog_path)
        if not demo:
            parsed = urlparse(url)
            if not confirmed or not key:
                raise SafeError('Live mode needs a fresh API key and confirmed API schema.')
            if parsed.scheme != 'https' or parsed.username or parsed.password or parsed.query or parsed.fragment:
                raise SafeError('API_URL must be an HTTPS endpoint without credentials or query parameters.')
            required = ('auth_field', 'action_field', 'products_action', 'order_action',
                        'success_path', 'success_value', 'products_path', 'product_fields',
                        'keys_path', 'order_id_path')
            if any(k not in self.mapping for k in required):
                raise SafeError('Adapter mapping is incomplete.')
            m = self.mapping
            if set(m['product_fields']) != {'pid', 'name', 'price', 'stock', 'currency'}:
                raise SafeError('Product field mapping must define all five fields.')
            if not all(isinstance(m[k], str) and m[k] for k in
                       ('auth_field', 'action_field', 'order_action')):
                raise SafeError('Invalid adapter field names.')
            notes_field = m.get('notes_field', 'customer_tag')
            if notes_field not in ('customer_tag', 'custom_notes'):
                raise SafeError('Unsupported customer notes field.')
            if m['auth_field'] == m['action_field'] or any(
                m[k] in {'pid', 'quantity', 'customer_tag', 'custom_notes'} for k in ('auth_field', 'action_field')
            ):
                raise SafeError('Adapter fields collide with order fields.')
            if m.get('body_format', 'form') not in ('json', 'form') or m.get('keys_format', 'list') not in ('single', 'list'):
                raise SafeError('Unsupported request or response format.')
            if m.get('pid_type', 'string') not in ('string', 'integer'):
                raise SafeError('Unsupported product ID type.')
            if m.get('catalog_source', 'remote') not in ('local', 'remote'):
                raise SafeError('Unsupported catalog source.')
            if m.get('catalog_source') == 'local':
                if not catalog_confirmed:
                    raise SafeError('Live mode needs actual catalog values and LIVE_CATALOG_CONFIRMED=true.')
                self.local_products()
            elif not isinstance(m['products_action'], str) or not m['products_action']:
                raise SafeError('Remote catalog action is not documented.')
            if m['products_action'] == m['order_action']:
                raise SafeError('Catalog and order actions must be different.')

    @classmethod
    def from_env(cls):
        demo = os.getenv('DEMO_MODE', 'true').lower() == 'true'
        mapping = {} if demo else json.loads(Path('adapter.json').read_text())
        return cls(demo, os.getenv('PANEL_API_KEY', ''),
                   os.getenv('API_URL', 'https://panelstore.shop/api/v1/index.php'), mapping,
                   os.getenv('API_SCHEMA_CONFIRMED', '').lower() == 'true',
                   catalog_path=os.getenv('CATALOG_PATH', 'catalog.json'),
                   catalog_confirmed=os.getenv('LIVE_CATALOG_CONFIRMED', '').lower() == 'true')

    def fingerprint(self):
        # Changing mode, account, endpoint or mapping invalidates outstanding approvals.
        identity = [self.demo, self.url, self.mapping, str(self.catalog_path), hashlib.sha256(self.key.encode()).hexdigest()]
        return hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()

    async def request(self, action, fields=None, require_success=True):
        m = self.mapping
        body = {m['auth_field']: self.key, m['action_field']: action, **(fields or {})}
        try:
            async with httpx.AsyncClient(timeout=25, follow_redirects=False,
                                         transport=self.transport, trust_env=False) as client:
                kwargs = {'json': body} if m.get('body_format', 'form') == 'json' else {'data': body}
                response = await client.post(self.url, **kwargs)
                response.raise_for_status()
                result = response.json()
                if not isinstance(result, dict):
                    raise ValueError('Expected an object')
                if require_success:
                    value = at(result, m['success_path'])
                    if type(value) is not type(m['success_value']) or value != m['success_value']:
                        raise ValueError('Not confirmed success')
                return result
        except (httpx.HTTPError, ValueError, KeyError, TypeError):
            # Never expose raw response, request URL, API key or provider exception.
            raise SafeError('Supplier response could not be confirmed.') from None

    def local_products(self):
        try:
            data = json.loads(self.catalog_path.read_text())
            rows = data['products']
            if not isinstance(rows, list) or len(rows) > 10000:
                raise ValueError()
            enabled = []
            for row in rows:
                if not isinstance(row, dict) or type(row.get('enabled')) is not bool:
                    raise ValueError()
                if row['enabled']:
                    enabled.append(row)
            result = self.parse_products(enabled, local=True)
            if not result:
                raise ValueError()
            return result
        except (OSError, KeyError, TypeError, ValueError):
            raise SafeError('Local catalog is missing or invalid. Fill and enable actual supplier products in catalog.json.') from None

    def parse_products(self, rows, local=False):
        try:
            if not isinstance(rows, list) or len(rows) > 10000:
                raise ValueError()
            products, seen = [], set()
            for row in rows:
                fields = {k: at(row, p) for k, p in self.mapping['product_fields'].items()}
                pid = str(fields['pid'])
                price = Decimal(str(fields['price']))
                customer_price = Decimal(str(row['customer_price'])) if local and 'customer_price' in row else None
                device_limit = row.get('device_limit') if local else None
                raw_stock = fields['stock']
                stock = None if local and raw_stock is None else int(raw_stock)
                if not re.fullmatch(r'[A-Za-z0-9_.-]{1,64}', pid) or pid in seen:
                    raise ValueError()
                if self.mapping.get('pid_type') == 'integer' and not re.fullmatch(r'[1-9][0-9]*', pid):
                    raise ValueError()
                if not price.is_finite() or price < 0:
                    raise ValueError()
                if customer_price is not None and (not customer_price.is_finite() or customer_price < 0):
                    raise ValueError()
                if device_limit is not None and (type(device_limit) is not int or device_limit < 1):
                    raise ValueError()
                if stock is not None and (stock < 0 or str(stock) != str(raw_stock)):
                    raise ValueError()
                if not isinstance(fields['name'], str) or not 1 <= len(fields['name']) <= 200:
                    raise ValueError()
                if not re.fullmatch(r'[A-Z]{3}', str(fields['currency'])):
                    raise ValueError()
                products.append(Product(pid, fields['name'], price, stock, fields['currency'], customer_price, device_limit))
                seen.add(pid)
            return products
        except (KeyError, TypeError, ValueError, InvalidOperation, OverflowError):
            raise SafeError('Catalog schema is not valid; check adapter.json against the documentation.') from None

    async def products(self):
        if self.demo:
            return [Product('demo-basic', 'Your App — Basic / 7 days', Decimal('10.00'), 99, 'INR'),
                    Product('demo-pro', 'Your App — Pro / 30 days', Decimal('25.00'), 99, 'INR')]
        if self.mapping.get('catalog_source') == 'local':
            return self.local_products()
        try:
            result = await self.request(self.mapping['products_action'])
            rows = at(result, self.mapping['products_path'])
            return self.parse_products(rows)
        except (KeyError, TypeError, ValueError, InvalidOperation, OverflowError):
            raise SafeError('Catalog schema is not valid; check adapter.json against the documentation.') from None

    def validate_quantity(self, quantity):
        if type(quantity) is not int or not 1 <= quantity <= 5:
            raise SafeError('Quantity must be 1–5.')
        if not self.demo and self.mapping.get('keys_format') == 'single' and quantity != 1:
            raise SafeError('The provided API example supports one returned key. Live quantity must be 1.')

    async def order(self, pid, quantity, tag):
        self.validate_quantity(quantity)
        if self.demo:
            return 'demo-' + tag, ['DEMO-NOT-VALID-' + uuid.uuid4().hex for _ in range(quantity)]
        if self.mapping.get('pid_type') == 'integer':
            if not re.fullmatch(r'[1-9][0-9]*', str(pid)):
                raise SafeError('Supplier PID must be a positive integer.')
            pid = int(pid)
        result = await self.request(self.mapping['order_action'],
                                    {'pid': pid, 'quantity': quantity,
                                     self.mapping.get('notes_field', 'customer_tag'): tag})
        try:
            keys = at(result, self.mapping['keys_path'])
            if self.mapping.get('keys_format') == 'single':
                keys = [keys]
            provider_id = at(result, self.mapping['order_id_path'])
            if not isinstance(keys, list) or len(keys) != quantity or isinstance(provider_id, bool) or not isinstance(provider_id, (str, int)) or not provider_id:
                raise ValueError()
            if any(not isinstance(k, str) or not k.strip() or len(k) > 2000 for k in keys):
                raise ValueError()
            if len(set(keys)) != len(keys):
                raise ValueError()
            return str(provider_id), keys
        except (KeyError, TypeError, ValueError):
            raise SafeError('Order result needs manual reconciliation; do not order again.') from None

    async def balance(self):
        if self.demo:
            return Decimal('0.00'), 'INR'
        try:
            result = await self.request(self.mapping['balance_action'], require_success=False)
            if 'status' in result and result['status'] != 'success':
                raise ValueError()
            amount = Decimal(str(result['balance']))
            currency = result['currency']
            if not amount.is_finite() or amount < 0 or not isinstance(currency, str) or not re.fullmatch(r'[A-Z]{3}', currency):
                raise ValueError()
            return amount, currency
        except (KeyError, TypeError, ValueError, InvalidOperation):
            raise SafeError('Wallet balance could not be confirmed.') from None


class Store:
    def __init__(self, path, encryption_key):
        self.cipher = Fernet(encryption_key)
        p = Path(path)
        p.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.db = sqlite3.connect(p, timeout=15)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS orders (
            id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
            quote TEXT NOT NULL, quantity INTEGER NOT NULL, state TEXT NOT NULL,
            created REAL NOT NULL, adapter TEXT NOT NULL, source TEXT UNIQUE NOT NULL,
            approver INTEGER, provider_id TEXT, keys_cipher BLOB, message_ids TEXT
        );
        CREATE UNIQUE INDEX IF NOT EXISTS one_unresolved_order_per_customer
        ON orders(user_id) WHERE state IN ('draft','pending','processing','uncertain');
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY, order_id TEXT NOT NULL,
            at REAL NOT NULL, event TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS payments (
            order_id TEXT PRIMARY KEY, status TEXT NOT NULL,
            amount TEXT NOT NULL, currency TEXT NOT NULL,
            qr_sha256 TEXT NOT NULL, payee_upi TEXT NOT NULL,
            qr_file TEXT NOT NULL, created REAL NOT NULL,
            evidence_cipher BLOB, reference_hash TEXT, screenshot_hash TEXT,
            verified_by INTEGER, verified_at REAL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS one_verified_utr
        ON payments(reference_hash) WHERE status='verified_manually' AND reference_hash IS NOT NULL;
        CREATE UNIQUE INDEX IF NOT EXISTS one_verified_screenshot
        ON payments(screenshot_hash) WHERE status='verified_manually' AND screenshot_hash IS NOT NULL;
        ''')
        self.db.commit()
        os.chmod(p, 0o600)
        existing = self.db.execute('SELECT keys_cipher FROM orders WHERE keys_cipher IS NOT NULL LIMIT 1').fetchone()
        if existing:
            self.cipher.decrypt(existing['keys_cipher'])
        evidence = self.db.execute('SELECT evidence_cipher FROM payments WHERE evidence_cipher IS NOT NULL LIMIT 1').fetchone()
        if evidence:
            self.cipher.decrypt(evidence['evidence_cipher'])

    def audit(self, oid, event):
        self.db.execute('INSERT INTO events(order_id,at,event) VALUES(?,?,?)', (oid, time.time(), event))

    def get(self, oid):
        row = self.db.execute('SELECT * FROM orders WHERE id=?', (oid,)).fetchone()
        if not row:
            raise SafeError('Order not found.')
        return dict(row)

    def create(self, user, chat, product, quantity, adapter, source):
        if not 1 <= quantity <= 5 or (product.stock is not None and product.stock < quantity):
            raise SafeError('Quantity must be 1–5 and within available stock.')
        with self.db:
            existing = self.db.execute('SELECT id FROM orders WHERE source=?', (source,)).fetchone()
            if existing:
                return existing['id']
            # One unresolved request per customer prevents accidental repeat purchases.
            active = self.db.execute("SELECT id FROM orders WHERE user_id=? AND state IN "
                                     "('draft','pending','processing','uncertain')", (user,)).fetchone()
            if active:
                raise SafeError('You already have an unresolved order; check /orders or contact the admin.')
            oid = uuid.uuid4().hex[:20]
            self.db.execute('INSERT INTO orders(id,user_id,chat_id,quote,quantity,state,created,adapter,source) '
                            'VALUES(?,?,?,?,?,?,?,?,?)',
                            (oid, user, chat, json.dumps(product.snapshot()), quantity,
                             'draft', time.time(), adapter, source))
            self.audit(oid, 'created')
        return oid

    def transition(self, oid, old, new, approver=None):
        with self.db:
            changed = self.db.execute('UPDATE orders SET state=?,approver=COALESCE(?,approver) '
                                      'WHERE id=? AND state=?', (new, approver, oid, old)).rowcount
            if changed:
                self.audit(oid, new)
        return changed == 1

    def purchased(self, oid, provider, keys):
        encrypted = self.cipher.encrypt(json.dumps(keys).encode())
        with self.db:
            changed = self.db.execute("UPDATE orders SET state='purchased',provider_id=?,keys_cipher=? "
                                      "WHERE id=? AND state='processing'", (provider, encrypted, oid)).rowcount
            if changed != 1:
                raise SafeError('Order needs manual reconciliation.')
            self.audit(oid, 'purchased')

    def keys(self, oid):
        row = self.get(oid)
        if not row['keys_cipher']:
            raise SafeError('No stored keys are available.')
        return json.loads(self.cipher.decrypt(row['keys_cipher']))

    def payment(self, oid):
        row = self.db.execute('SELECT * FROM payments WHERE order_id=?', (oid,)).fetchone()
        return dict(row) if row else None

    def create_payment(self, oid, asset):
        order = self.get(oid)
        quote = json.loads(order['quote'])
        if (order['state'] != 'pending' or order['quantity'] != 1 or
                quote['pid'] != asset.pid or Decimal(quote['customer_price']) != asset.amount or
                quote['currency'] != asset.currency):
            raise SafeError('Payment instructions do not match this pending order.')
        existing = self.payment(oid)
        if existing:
            if (Decimal(existing['amount']) != asset.amount or existing['currency'] != asset.currency or
                    existing['qr_sha256'] != asset.sha256 or existing['payee_upi'] != asset.payee_upi):
                raise SafeError('Payment instructions changed; contact the admin before paying again.')
            return existing
        with self.db:
            self.db.execute('INSERT INTO payments(order_id,status,amount,currency,qr_sha256,payee_upi,qr_file,created) '
                            'VALUES(?,?,?,?,?,?,?,?)', (oid, 'awaiting_manual_verification', str(asset.amount),
                            asset.currency, asset.sha256, asset.payee_upi, asset.path.name, time.time()))
            self.audit(oid, 'payment_awaiting_manual_verification')
        return self.payment(oid)

    def payment_evidence(self, oid):
        row = self.payment(oid)
        return json.loads(self.cipher.decrypt(row['evidence_cipher'])) if row and row['evidence_cipher'] else {}

    def payment_reference(self, oid):
        return self.payment_evidence(oid).get('reference', '')

    def report_payment(self, oid, user, reference=None, screenshot_file_id=None,
                       screenshot_kind=None, screenshot_unique_id=None):
        order, payment = self.get(oid), self.payment(oid)
        if order['user_id'] != user:
            raise SafeError('Order not found.')
        if order['state'] != 'pending' or not payment:
            raise SafeError('This order is not awaiting payment evidence. Contact the admin if you already paid.')
        if payment['status'] == 'verified_manually':
            raise SafeError('Payment was already manually verified; wait for supplier approval.')
        evidence = self.payment_evidence(oid)
        if reference is not None:
            if not isinstance(reference, str) or not re.fullmatch(r'[A-Za-z0-9._-]{6,80}', reference):
                raise SafeError('Send a valid UTR/reference (6–80 letters, digits, dots, underscores or hyphens).')
            evidence['reference'] = reference
        if screenshot_file_id is not None:
            if (screenshot_kind not in ('photo', 'document') or not isinstance(screenshot_file_id, str) or
                    not 1 <= len(screenshot_file_id) <= 1000):
                raise SafeError('Payment screenshot could not be attached.')
            evidence.update(screenshot_file_id=screenshot_file_id, screenshot_kind=screenshot_kind,
                            screenshot_unique_id=screenshot_unique_id or screenshot_file_id)
        if not evidence:
            raise SafeError('Send a UTR/reference or a payment screenshot for admin review.')
        ref = evidence.get('reference')
        screenshot = evidence.get('screenshot_unique_id')
        encrypted = self.cipher.encrypt(json.dumps(evidence).encode())
        with self.db:
            changed = self.db.execute("UPDATE payments SET status='customer_reported',evidence_cipher=?,"
                                     "reference_hash=?,screenshot_hash=? WHERE order_id=? AND status IN "
                                     "('awaiting_manual_verification','customer_reported')", (encrypted,
                                     hashlib.sha256(ref.lower().encode()).hexdigest() if ref else None,
                                     hashlib.sha256(screenshot.encode()).hexdigest() if screenshot else None, oid)).rowcount
            if changed != 1:
                raise SafeError('Payment review state changed; contact the admin.')
            self.audit(oid, 'customer_reported_payment_not_verified')

    def payment_verified(self, oid):
        order, payment = self.get(oid), self.payment(oid)
        if not payment or payment['status'] != 'verified_manually':
            return False
        quote = json.loads(order['quote'])
        return (order['quantity'] == 1 and Decimal(quote.get('customer_price', '-1')) == Decimal(payment['amount'])
                and quote['currency'] == payment['currency'] and payment['verified_by'] is not None)

    def verify_payment(self, oid, admin):
        order, payment = self.get(oid), self.payment(oid)
        if order['state'] != 'pending' or not payment or payment['status'] != 'customer_reported':
            raise SafeError('A pending order with customer-submitted UTR or screenshot is required.')
        quote = json.loads(order['quote'])
        if (not self.payment_evidence(oid) or order['quantity'] != 1 or
                Decimal(quote.get('customer_price', '-1')) != Decimal(payment['amount']) or
                quote['currency'] != payment['currency']):
            raise SafeError('Payment evidence or amount does not match this order; reconcile manually.')
        try:
            with self.db:
                changed = self.db.execute("UPDATE payments SET status='verified_manually',verified_by=?,verified_at=? "
                                         "WHERE order_id=? AND status='customer_reported'",
                                         (admin, time.time(), oid)).rowcount
                if changed != 1:
                    raise SafeError('Payment was already handled.')
                self.audit(oid, 'payment_marked_verified_by_admin')
        except sqlite3.IntegrityError:
            raise SafeError('This UTR or screenshot was already verified for another order. Reconcile in the bank app.') from None

    def list_orders(self, user=None, pending=False):
        if pending:
            rows = self.db.execute("SELECT * FROM orders WHERE state IN ('pending','processing','uncertain','purchased') "
                                   'ORDER BY created DESC LIMIT 30')
        elif user is not None:
            rows = self.db.execute('SELECT * FROM orders WHERE user_id=? ORDER BY created DESC LIMIT 20', (user,))
        else:
            rows = self.db.execute('SELECT * FROM orders ORDER BY created DESC LIMIT 30')
        return [dict(r) for r in rows]

    def delivered(self, oid, ids):
        with self.db:
            self.db.execute("UPDATE orders SET state='delivered',message_ids=? WHERE id=? "
                            "AND state IN ('purchased','delivered')", (json.dumps(ids), oid))
            self.audit(oid, 'delivered')


class Engine:
    def __init__(self, store, supplier, require_payment=False):
        self.store, self.supplier = store, supplier
        self.require_payment = require_payment

    async def approve(self, oid, admin):
        row = self.store.get(oid)
        if row['state'] != 'pending':
            raise SafeError('Already handled or not pending; no supplier request was made.')
        if self.require_payment and not self.store.payment_verified(oid):
            raise SafeError('Payment is awaiting manual verification. No supplier order was sent.')
        if time.time() - row['created'] > 900:
            self.store.transition(oid, 'pending', 'expired')
            raise SafeError('Quote expired. Create a fresh order.')
        if row['adapter'] != self.supplier.fingerprint():
            self.store.transition(oid, 'pending', 'expired')
            raise SafeError('Supplier configuration changed; request a fresh quote.')
        if hasattr(self.supplier, 'validate_quantity'):
            self.supplier.validate_quantity(row['quantity'])
        quote = json.loads(row['quote'])
        products = await self.supplier.products()
        current = next((p for p in products if p.pid == quote['pid']), None)
        if (current is None or current.price != Decimal(quote['price']) or
                current.selling_price != Decimal(quote.get('customer_price', quote['price'])) or
                current.device_limit != quote.get('device_limit') or
                current.currency != quote['currency'] or current.name != quote['name'] or
                (current.stock is not None and current.stock < row['quantity'])):
            self.store.transition(oid, 'pending', 'expired')
            raise SafeError('Product, customer price, supplier cost, device limit, currency or stock changed; request a fresh quote.')
        if not self.store.transition(oid, 'pending', 'processing', admin):
            raise SafeError('Another worker already handled this order.')
        try:
            provider, keys = await self.supplier.order(quote['pid'], row['quantity'], oid)
            if (not isinstance(provider, str) or not provider or not isinstance(keys, list)
                    or len(keys) != row['quantity']
                    or any(not isinstance(k, str) or not k.strip() or len(k) > 2000 for k in keys)
                    or len(set(keys)) != len(keys)):
                raise SafeError('Malformed supplier order result.')
            self.store.purchased(oid, provider, keys)
        except Exception:
            self.store.transition(oid, 'processing', 'uncertain')
            raise SafeError('Order outcome is uncertain. Reconcile in the supplier panel; DO NOT repurchase.') from None
        return self.store.get(oid)
