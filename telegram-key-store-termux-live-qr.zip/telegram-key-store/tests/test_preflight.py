import json
import shutil
from pathlib import Path

import httpx
import pytest
from cryptography.fernet import Fernet

import preflight

ROOT = Path(__file__).parents[1]


@pytest.fixture
def live_env(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(preflight, 'load_dotenv', lambda: None)
    for name in ('adapter.json', 'catalog.json'):
        (tmp_path / name).write_text((ROOT / name).read_text())
    shutil.copytree(ROOT / 'assets', tmp_path / 'assets')
    values = {
        'DEMO_MODE': 'false', 'API_SCHEMA_CONFIRMED': 'true',
        'LIVE_CATALOG_CONFIRMED': 'true', 'API_URL': 'https://supplier.example/api',
        'CATALOG_PATH': 'catalog.json', 'PANEL_API_KEY': 'fake-local-key',
        'TELEGRAM_BOT_TOKEN': '123456:abcdefghijklmnopqrstuvwxyz_123456',
        'ADMIN_IDS': '20', 'ALLOWED_USER_IDS': '10',
        'FERNET_KEY': Fernet.generate_key().decode(),
    }
    for name, value in values.items():
        monkeypatch.setenv(name, value)
    async def forbid_network(*args, **kwargs):
        raise AssertionError('Preflight must never access the network')
    monkeypatch.setattr(httpx.AsyncClient, 'post', forbid_network)
    return tmp_path


def test_preflight_validates_live_profile_without_network(live_env, capsys):
    assert preflight.check() == 0
    out = capsys.readouterr().out
    assert 'READY: 9 enabled plans' in out
    assert 'No Telegram or supplier request was made' in out
    assert 'fake-local-key' not in out
    assert 'abcdefghijklmnopqrstuvwxyz' not in out


@pytest.mark.parametrize('name,value', [
    ('PANEL_API_KEY', ''), ('PANEL_API_KEY', 'YOUR_NEW_API_KEY'),
    ('LIVE_CATALOG_CONFIRMED', 'false'), ('ADMIN_IDS', ''),
    ('ADMIN_IDS', '-1'), ('TELEGRAM_BOT_TOKEN', ''), ('FERNET_KEY', ''),
    ('DEMO_MODE', 'true'),
])
def test_preflight_blocks_incomplete_configuration(live_env, monkeypatch, capsys, name, value):
    monkeypatch.setenv(name, value)
    assert preflight.check() == 1
    assert 'BLOCKED:' in capsys.readouterr().out


def test_preflight_rejects_missing_explicit_selling_price(live_env, capsys):
    path = live_env / 'catalog.json'
    data = json.loads(path.read_text())
    del data['products'][0]['customer_price']
    path.write_text(json.dumps(data))
    assert preflight.check() == 1
    assert 'customer_price' in capsys.readouterr().out


def test_preflight_blocks_missing_qr_asset(live_env, capsys):
    (live_env / 'assets/payments/qr_343.png').unlink()
    assert preflight.check() == 1
    assert 'payment QR' in capsys.readouterr().out
