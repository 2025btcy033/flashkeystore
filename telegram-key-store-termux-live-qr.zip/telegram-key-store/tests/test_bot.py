import asyncio
import json
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock

import pytest
from cryptography.fernet import Fernet

from bot import Bot
from core import SafeError, Store, Supplier


def update(user=10, chat=10, kind='private', command='/orders'):
    return NS(effective_user=NS(id=user), effective_chat=NS(id=chat, type=kind),
              effective_message=NS(text=command, reply_text=AsyncMock()), update_id=42)


@pytest.fixture
def setup(tmp_path):
    store = Store(tmp_path / 'db.sqlite3', Fernet.generate_key())
    supplier = Supplier(demo=True)
    bot = Bot(store, supplier, admins={20}, users={10})
    context = NS(bot=NS(send_document=AsyncMock(return_value=NS(message_id=101)),
                        send_message=AsyncMock()), args=[])
    yield store, supplier, bot, context
    store.db.close()


def purchased(store, supplier):
    async def run():
        product = (await supplier.products())[0]
        oid = store.create(10, 10, product, 1, supplier.fingerprint(), 'msg-1')
        store.transition(oid, 'draft', 'pending')
        from core import Engine
        await Engine(store, supplier).approve(oid, 20)
        return oid
    return asyncio.run(run())


def test_allowlist_is_fail_closed(setup):
    _, _, bot, _ = setup
    assert bot.allowed(update())
    assert bot.allowed(update(20, 20), admin=True)
    assert not bot.allowed(update(), admin=True)
    assert not bot.allowed(update(99, 99))
    assert not bot.allowed(update(10, -123, 'group'))
    assert not bot.allowed(update(10, 20))


def test_empty_allowlist_only_admins(setup):
    store, supplier, _, _ = setup
    bot = Bot(store, supplier, {20}, set())
    assert not bot.allowed(update(10, 10))
    assert bot.allowed(update(20, 20))


def test_non_admin_cannot_lookup_admin_order_command(setup):
    _, _, bot, context = setup
    context.args = ['unknown-order']
    u = update(command='/approve unknown-order')
    asyncio.run(bot.command(u, context))
    u.effective_message.reply_text.assert_awaited_once_with('Admin only.')


def test_customer_cannot_retrieve_someone_elses_keys(setup):
    store, supplier, bot, context = setup
    oid = purchased(store, supplier)
    u = update(20, 20, command='/keys ' + oid)
    context.args = [oid]
    asyncio.run(bot.command(u, context))
    context.bot.send_document.assert_not_awaited()
    u.effective_message.reply_text.assert_awaited_once_with('Order not found.')


def test_delivery_retries_only_stored_keys(setup):
    store, supplier, bot, context = setup
    oid = purchased(store, supplier)
    supplier.order = AsyncMock(side_effect=AssertionError('Do not order again'))
    asyncio.run(bot.deliver(context, oid))
    asyncio.run(bot.deliver(context, oid))
    assert context.bot.send_document.await_count == 2
    supplier.order.assert_not_awaited()
    assert store.get(oid)['state'] == 'delivered'
    assert json.loads(store.get(oid)['message_ids']) == [101]
    for call in context.bot.send_document.await_args_list:
        assert call.kwargs['chat_id'] == 10
        assert call.kwargs['protect_content'] is True


def test_delivery_error_does_not_repurchase(setup):
    store, supplier, bot, context = setup
    oid = purchased(store, supplier)
    supplier.order = AsyncMock()
    context.bot.send_document.side_effect = RuntimeError('a private Telegram URL with token')
    with pytest.raises(SafeError, match='do not repurchase'):
        asyncio.run(bot.deliver(context, oid))
    assert store.get(oid)['state'] == 'purchased'
    supplier.order.assert_not_awaited()


def test_revoked_customer_no_key_delivery(setup):
    store, supplier, bot, context = setup
    oid = purchased(store, supplier)
    bot.users.remove(10)
    with pytest.raises(SafeError, match='revoked'):
        asyncio.run(bot.deliver(context, oid))
    context.bot.send_document.assert_not_awaited()


def test_admin_approve_command_previews_without_purchase(setup):
    store, supplier, bot, context = setup
    p = asyncio.run(supplier.products())[0]
    oid = store.create(10, 10, p, 1, supplier.fingerprint(), 'msg-1')
    store.transition(oid, 'draft', 'pending')
    supplier.order = AsyncMock()
    context.args = [oid]
    u = update(20, 20, command='/approve ' + oid)
    asyncio.run(bot.command(u, context))
    supplier.order.assert_not_awaited()
    assert store.get(oid)['state'] == 'pending'
    assert 'Confirm the supplier order' in u.effective_message.reply_text.await_args.args[0]
