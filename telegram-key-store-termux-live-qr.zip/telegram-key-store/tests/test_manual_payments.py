import asyncio
import hashlib
import json
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock

import httpx
import pytest
from cryptography.fernet import Fernet

from bot import Bot
from core import Engine, Product, SafeError, Store, Supplier
from payments import PaymentCatalog

ROOT = Path(__file__).resolve().parents[1]
CUSTOMER, ADMIN = 10, 20


def update(user=CUSTOMER, chat=None, command='/orders', data=None):
    return NS(effective_user=NS(id=user), effective_chat=NS(id=user if chat is None else chat, type='private'),
              effective_message=NS(text=command, reply_text=AsyncMock()), update_id=42,
              callback_query=NS(data=data, answer=AsyncMock(), edit_message_text=AsyncMock()) if data else None)


def make_manifest(tmp_path, amount='12.00', pid='343', payload=None, data=b'fake-png-bytes'):
    qr = tmp_path / 'qr.png'
    qr.write_bytes(data)
    payload = payload or 'upi://pay?pa=owner%40upi&pn=Owner&am=12.00&cu=INR'
    path = tmp_path / 'manifest.json'
    path.write_text(json.dumps({'entries': [{'pid': pid, 'amount': amount, 'currency': 'INR', 'file': qr.name,
        'sha256': hashlib.sha256(data).hexdigest(), 'payload': payload, 'payee_upi': 'owner@upi', 'payee_name': 'Owner'}]}))
    return path, qr


def test_catalog_validates_amount_payee_file_hash_and_pid(tmp_path):
    path, qr = make_manifest(tmp_path)
    catalog = PaymentCatalog(path)
    row = {'quote': json.dumps({'pid': '343', 'customer_price': '12.00', 'currency': 'INR'}), 'quantity': 1}
    asset = catalog.for_order(row)
    assert asset.amount == Decimal('12') and asset.path == qr and asset.payee_upi == 'owner@upi'
    for changes in ({'pid': '999'}, {'customer_price': '11'}, {'currency': 'USD'}):
        q = json.loads(row['quote']); q.update(changes)
        with pytest.raises(SafeError):
            catalog.for_order({**row, 'quote': json.dumps(q)})
    qr.write_bytes(b'changed')
    with pytest.raises(SafeError):
        catalog.for_order(row)


@pytest.fixture
def payment_setup(tmp_path):
    manifest, _ = make_manifest(tmp_path)
    mapping = json.loads((ROOT / 'adapter.json').read_text())
    catalog_path = tmp_path / 'catalog.json'
    catalog_path.write_text(json.dumps({'products': [{'enabled': True, 'pid': '343', 'name': 'PHANTOM — 1 Hour',
        'supplier_cost': '7.00', 'customer_price': '12.00', 'device_limit': 1, 'stock': None, 'currency': 'INR'}]}))
    supplier = Supplier(False, 'fake-key', 'https://supplier.example/api', mapping, confirmed=True,
        transport=httpx.MockTransport(lambda req: httpx.Response(200, json={'status': 'success', 'license_key': 'secret-key', 'order_code': 'O1'})),
        catalog_path=catalog_path, catalog_confirmed=True)
    supplier.order = AsyncMock(wraps=supplier.order)
    store = Store(tmp_path / 'db.sqlite3', Fernet.generate_key())
    bot = Bot(store, supplier, {ADMIN}, {CUSTOMER, 11}, payments=PaymentCatalog(manifest))
    sent_bytes = []
    async def send_document(**kwargs):
        document = kwargs['document']
        if hasattr(document, 'read'):
            sent_bytes.append(document.read())
        return NS(message_id=901)
    context = NS(bot=NS(send_document=AsyncMock(side_effect=send_document),
        send_photo=AsyncMock(return_value=NS(message_id=902)), send_message=AsyncMock()), args=[], sent_bytes=sent_bytes)
    yield store, supplier, bot, context
    store.db.close()


def command(bot, context, user, text, args):
    bot.last.clear()
    context.args = args
    u = update(user=user, command=text)
    asyncio.run(bot.command(u, context))
    return u


def draft(setup):
    store, supplier, bot, context = setup
    command(bot, context, CUSTOMER, '/buy 343 1', ['343', '1'])
    oid = store.list_orders(user=CUSTOMER)[0]['id']
    assert store.get(oid)['state'] == 'draft'
    supplier.order.assert_not_awaited()
    return oid


def callback(setup, oid, action, user=CUSTOMER):
    u = update(user=user, data=action + ':' + oid)
    asyncio.run(setup[2].callback(u, setup[3]))
    return u


def request(setup):
    oid = draft(setup)
    callback(setup, oid, 'request')
    assert setup[0].get(oid)['state'] == 'pending'
    return oid


def test_request_sends_matching_qr_and_no_supplier_order(payment_setup):
    store, supplier, bot, context = payment_setup
    oid = request(payment_setup)
    assert store.payment(oid)['status'] == 'awaiting_manual_verification'
    assert context.sent_bytes == [b'fake-png-bytes']
    sent = context.bot.send_document.await_args.kwargs
    assert sent['chat_id'] == CUSTOMER and '12.00 INR' in sent['caption']
    assert 'awaiting manual verification' in sent['caption']
    supplier.order.assert_not_awaited()


def test_customer_cannot_use_foreign_order_or_verify(payment_setup):
    store, supplier, bot, context = payment_setup
    oid = request(payment_setup)
    other = command(bot, context, 11, '/payment ' + oid, [oid])
    assert other.effective_message.reply_text.await_args.args[0] == 'Order not found.'
    command(bot, context, 11, '/paid ' + oid + ' REF-9999', [oid, 'REF-9999'])
    callback(payment_setup, oid, 'verify')
    assert store.payment(oid)['status'] == 'awaiting_manual_verification'
    supplier.order.assert_not_awaited()


def test_utr_needs_manual_verify_and_final_approval_once(payment_setup):
    store, supplier, bot, context = payment_setup
    oid = request(payment_setup)
    command(bot, context, CUSTOMER, '/paid ' + oid + ' UTR-123456', [oid, 'UTR-123456'])
    assert store.payment(oid)['status'] == 'customer_reported'
    assert store.payment_reference(oid) == 'UTR-123456'
    assert b'UTR-123456' not in store.payment(oid)['evidence_cipher']
    callback(payment_setup, oid, 'approve', ADMIN)
    supplier.order.assert_not_awaited()
    command(bot, context, ADMIN, '/verifypayment ' + oid, [oid])
    assert not store.payment_verified(oid)
    callback(payment_setup, oid, 'verify', ADMIN)
    assert store.payment_verified(oid)
    supplier.order.assert_not_awaited()
    command(bot, context, ADMIN, '/approve ' + oid, [oid])
    supplier.order.assert_not_awaited()
    callback(payment_setup, oid, 'approve', ADMIN)
    assert store.get(oid)['state'] == 'delivered'
    assert supplier.order.await_count == 1
    assert context.bot.send_document.await_args.kwargs['chat_id'] == CUSTOMER
    callback(payment_setup, oid, 'approve', ADMIN)
    assert supplier.order.await_count == 1


def test_qr_delivery_failure_can_resend_without_purchase(payment_setup):
    store, supplier, bot, context = payment_setup
    context.bot.send_document.side_effect = RuntimeError('Telegram unavailable')
    oid = request(payment_setup)
    assert store.payment(oid)['status'] == 'awaiting_manual_verification'
    context.bot.send_document.side_effect = None
    command(bot, context, CUSTOMER, '/payment ' + oid, [oid])
    assert context.bot.send_document.await_count == 2
    supplier.order.assert_not_awaited()


def screenshot(oid, user=CUSTOMER, kind='photo', unique='unique-receipt'):
    image = NS(file_id='receipt-large', file_unique_id=unique, mime_type='image/png')
    return NS(effective_user=NS(id=user), effective_chat=NS(id=user, type='private'),
        effective_message=NS(photo=[image] if kind == 'photo' else [], document=image if kind == 'document' else None,
            caption=oid, reply_text=AsyncMock()))


@pytest.mark.parametrize('kind', ['photo', 'document'])
def test_screenshot_only_is_encrypted_forwarded_and_not_auto_verified(payment_setup, kind):
    store, supplier, bot, context = payment_setup
    oid = request(payment_setup)
    u = screenshot(oid, kind=kind)
    asyncio.run(bot.receipt(u, context))
    evidence = store.payment_evidence(oid)
    assert evidence['screenshot_file_id'] == 'receipt-large'
    assert store.payment_reference(oid) == ''
    assert b'receipt-large' not in store.payment(oid)['evidence_cipher']
    assert store.payment(oid)['status'] == 'customer_reported'
    sent = context.bot.send_photo if kind == 'photo' else context.bot.send_document
    assert sent.await_args.kwargs['chat_id'] == ADMIN
    assert not store.payment_verified(oid)
    callback(payment_setup, oid, 'verify', ADMIN)
    assert store.payment_verified(oid)
    supplier.order.assert_not_awaited()


def test_foreign_or_group_receipt_rejected(payment_setup):
    store, supplier, bot, context = payment_setup
    oid = request(payment_setup)
    for u in (screenshot(oid, user=11), screenshot(oid)):
        if u.effective_user.id == CUSTOMER:
            u.effective_chat.type = 'group'; u.effective_chat.id = -100
        asyncio.run(bot.receipt(u, context))
    assert store.payment(oid)['status'] == 'awaiting_manual_verification'
    supplier.order.assert_not_awaited()


def test_evidence_reuse_cancellation_and_changed_qr_fail_closed(payment_setup):
    store, supplier, bot, context = payment_setup
    oid = request(payment_setup)
    command(bot, context, CUSTOMER, '/paid ' + oid + ' SAME-123456', [oid, 'SAME-123456'])
    with pytest.raises(SafeError):
        bot.cancel(store.get(oid))
    store.verify_payment(oid, ADMIN)
    p = asyncio.run(supplier.products())[0]
    second = store.create(11, 11, p, 1, supplier.fingerprint(), 'second')
    store.transition(second, 'draft', 'pending')
    asset = bot.payments.for_order(store.get(second))
    store.create_payment(second, asset)
    store.report_payment(second, 11, 'SAME-123456')
    with pytest.raises(SafeError, match='already verified'):
        store.verify_payment(second, ADMIN)
    asset.path.write_bytes(b'tampered')
    callback(payment_setup, oid, 'approve', ADMIN)
    supplier.order.assert_not_awaited()


def test_engine_requires_verified_payment_even_on_direct_approve(payment_setup):
    store, supplier, bot, context = payment_setup
    oid = request(payment_setup)
    with pytest.raises(SafeError, match='Payment'):
        asyncio.run(Engine(store, supplier, require_payment=True).approve(oid, ADMIN))
    supplier.order.assert_not_awaited()
