import asyncio
import json
import sqlite3
import time
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest
from cryptography.fernet import Fernet

from core import Engine, Product, SafeError, Store, Supplier


KEY = Fernet.generate_key()


def make_store(tmp_path):
    return Store(tmp_path / "store.sqlite3", KEY)


def make_pending(store, supplier, user=7, source=None, product=None):
    product = product or Product("p1", "Plan", Decimal("10.00"), 5, "USD")
    oid = store.create(user, user, product, 1, supplier.fingerprint(), source or f"source-{user}-{time.time_ns()}")
    assert store.transition(oid, "draft", "pending")
    return oid


class CountingSupplier:
    demo = True

    def __init__(self, products=None, order_result=None, order_error=None, delay=0):
        self._products = products or [Product("p1", "Plan", Decimal("10.00"), 5, "USD")]
        self.order_result = order_result or ("provider-1", ["key-1"])
        self.order_error = order_error
        self.delay = delay
        self.order_calls = 0

    def fingerprint(self):
        return "counting-fingerprint"

    async def products(self):
        return self._products

    async def order(self, pid, quantity, tag):
        self.order_calls += 1
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.order_error:
            raise self.order_error
        return self.order_result


def test_demo_products_and_order_are_local():
    supplier = Supplier(demo=True)

    async def run():
        products = await supplier.products()
        provider, keys = await supplier.order(products[0].pid, 2, "tag")
        return products, provider, keys

    products, provider, keys = asyncio.run(run())
    assert [p.pid for p in products] == ["demo-basic", "demo-pro"]
    assert provider == "demo-tag"
    assert len(keys) == 2


def test_store_encrypts_keys_and_round_trips(tmp_path):
    store = make_store(tmp_path)
    supplier = CountingSupplier()
    oid = make_pending(store, supplier)
    assert store.transition(oid, "pending", "processing")
    store.purchased(oid, "provider", ["SECRET-KEY"])
    raw = Path(tmp_path / "store.sqlite3").read_bytes()
    assert b"SECRET-KEY" not in raw
    assert store.keys(oid) == ["SECRET-KEY"]
    assert (Path(tmp_path / "store.sqlite3").stat().st_mode & 0o777) == 0o600


def test_duplicate_source_returns_same_order(tmp_path):
    store = make_store(tmp_path)
    p = Product("p1", "Plan", Decimal("10"), 2, "USD")
    a = store.create(1, 1, p, 1, "adapter", "telegram-update-1")
    b = store.create(1, 1, p, 1, "adapter", "telegram-update-1")
    assert a == b
    assert len(store.list_orders(user=1)) == 1


def test_unresolved_order_blocks_second_customer_order(tmp_path):
    store = make_store(tmp_path)
    supplier = CountingSupplier()
    product = Product("p1", "Plan", Decimal("10"), 2, "USD")
    store.create(11, 11, product, 1, supplier.fingerprint(), "first")
    with pytest.raises(SafeError, match="unresolved"):
        store.create(11, 11, product, 1, supplier.fingerprint(), "second")


def test_duplicate_approval_only_places_one_supplier_order(tmp_path):
    store = make_store(tmp_path)
    supplier = CountingSupplier()
    oid = make_pending(store, supplier)
    result = asyncio.run(Engine(store, supplier).approve(oid, 99))
    assert result["state"] == "purchased"
    with pytest.raises(SafeError, match="Already handled"):
        asyncio.run(Engine(store, supplier).approve(oid, 99))
    assert supplier.order_calls == 1


def test_concurrent_approval_only_one_succeeds(tmp_path):
    store = make_store(tmp_path)
    supplier = CountingSupplier(delay=0.01)
    oid = make_pending(store, supplier)

    async def run():
        return await asyncio.gather(
            Engine(store, supplier).approve(oid, 1),
            Engine(store, supplier).approve(oid, 2),
            return_exceptions=True,
        )

    results = asyncio.run(run())
    assert sum(not isinstance(x, Exception) for x in results) == 1
    assert supplier.order_calls == 1
    assert store.get(oid)["state"] == "purchased"


def test_malformed_order_becomes_uncertain_and_is_not_reordered(tmp_path):
    store = make_store(tmp_path)
    supplier = CountingSupplier(order_result=("provider", ["only-one", "extra"]))
    oid = make_pending(store, supplier)
    with pytest.raises(SafeError, match="uncertain"):
        asyncio.run(Engine(store, supplier).approve(oid, 1))
    assert store.get(oid)["state"] == "uncertain"
    with pytest.raises(SafeError, match="Already handled"):
        asyncio.run(Engine(store, supplier).approve(oid, 1))
    assert supplier.order_calls == 1


def test_supplier_timeout_becomes_uncertain(tmp_path):
    store = make_store(tmp_path)
    supplier = CountingSupplier(order_error=httpx.ReadTimeout("provider timed out"))
    oid = make_pending(store, supplier)
    with pytest.raises(SafeError, match="uncertain"):
        asyncio.run(Engine(store, supplier).approve(oid, 1))
    assert store.get(oid)["state"] == "uncertain"


def test_price_change_expires_quote_without_order(tmp_path):
    store = make_store(tmp_path)
    supplier = CountingSupplier(products=[Product("p1", "Plan", Decimal("11"), 5, "USD")])
    oid = make_pending(store, supplier)
    with pytest.raises(SafeError, match="changed"):
        asyncio.run(Engine(store, supplier).approve(oid, 1))
    assert store.get(oid)["state"] == "expired"
    assert supplier.order_calls == 0


def test_stock_change_expires_quote_without_order(tmp_path):
    store = make_store(tmp_path)
    supplier = CountingSupplier(products=[Product("p1", "Plan", Decimal("10"), 0, "USD")])
    oid = make_pending(store, supplier)
    with pytest.raises(SafeError, match="changed"):
        asyncio.run(Engine(store, supplier).approve(oid, 1))
    assert store.get(oid)["state"] == "expired"
    assert supplier.order_calls == 0


def test_adapter_change_invalidates_quote(tmp_path):
    store = make_store(tmp_path)
    supplier = CountingSupplier()
    oid = make_pending(store, supplier)
    supplier.fingerprint = lambda: "changed-fingerprint"
    with pytest.raises(SafeError, match="configuration changed"):
        asyncio.run(Engine(store, supplier).approve(oid, 1))
    assert store.get(oid)["state"] == "expired"
    assert supplier.order_calls == 0


def test_old_quote_expires_without_catalog_or_order_call(tmp_path):
    store = make_store(tmp_path)
    supplier = CountingSupplier()
    oid = make_pending(store, supplier)
    store.db.execute("UPDATE orders SET created=? WHERE id=?", (time.time() - 901, oid))
    store.db.commit()
    with pytest.raises(SafeError, match="expired"):
        asyncio.run(Engine(store, supplier).approve(oid, 1))
    assert store.get(oid)["state"] == "expired"
    assert supplier.order_calls == 0


def live_mapping():
    return {
        "auth_field": "api_key", "action_field": "action", "products_action": "list",
        "order_action": "buy", "success_path": "ok", "success_value": True,
        "products_path": "products", "product_fields": {
            "pid": "id", "name": "name", "price": "price", "stock": "stock", "currency": "currency"
        }, "keys_path": "keys", "order_id_path": "order_id",
    }


def test_auth_field_collision_rejected_at_startup():
    mapping = live_mapping()
    mapping["auth_field"] = "pid"
    with pytest.raises(SafeError, match="collide"):
        Supplier(False, "secret", "https://supplier.example/api", mapping, confirmed=True)


def test_invalid_catalog_types_are_safe_error():
    mapping = live_mapping()

    def handler(request):
        return httpx.Response(200, json={"ok": True, "products": [{
            "id": "p1", "name": "Plan", "price": "not-money", "stock": 2, "currency": "USD"
        }]})

    supplier = Supplier(False, "secret", "https://supplier.example/api", mapping,
                        confirmed=True, transport=httpx.MockTransport(handler))
    with pytest.raises(SafeError, match="Catalog schema is not valid"):
        asyncio.run(supplier.products())


def test_duplicate_catalog_ids_are_rejected():
    mapping = live_mapping()

    def handler(request):
        row = {"id": "p1", "name": "Plan", "price": "1.00", "stock": 2, "currency": "USD"}
        return httpx.Response(200, json={"ok": True, "products": [row, row]})

    supplier = Supplier(False, "secret", "https://supplier.example/api", mapping,
                        confirmed=True, transport=httpx.MockTransport(handler))
    with pytest.raises(SafeError, match="Catalog schema is not valid"):
        asyncio.run(supplier.products())


def test_http_request_has_no_retries_and_redacts_safe_error():
    calls = []

    def handler(request):
        calls.append(request)
        return httpx.Response(500, text="private provider payload")

    supplier = Supplier(False, "TOP-SECRET-KEY", "https://supplier.example/api",
                        live_mapping(), confirmed=True, transport=httpx.MockTransport(handler))
    with pytest.raises(SafeError) as exc:
        asyncio.run(supplier.request("list"))
    assert len(calls) == 1
    assert "TOP-SECRET-KEY" not in str(exc.value)
    assert "private provider payload" not in str(exc.value)
    assert "supplier.example" not in str(exc.value)


def test_bot_allowed_requires_private_self_chat_and_allowlist():
    # Static authorization contract: group chats and user/chat mismatches must never pass.
    from bot import Bot

    bot = Bot(None, SimpleNamespace(demo=True), admins={10}, users={20})
    good = SimpleNamespace(effective_user=SimpleNamespace(id=20),
                           effective_chat=SimpleNamespace(id=20, type="private"))
    group = SimpleNamespace(effective_user=SimpleNamespace(id=20),
                            effective_chat=SimpleNamespace(id=-20, type="group"))
    mismatch = SimpleNamespace(effective_user=SimpleNamespace(id=20),
                               effective_chat=SimpleNamespace(id=21, type="private"))
    assert bot.allowed(good)
    assert bot.allowed(good, admin=False)
    assert not bot.allowed(group)
    assert not bot.allowed(mismatch)
    assert not bot.allowed(good, admin=True)
