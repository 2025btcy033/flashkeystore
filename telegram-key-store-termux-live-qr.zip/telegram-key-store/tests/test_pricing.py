import asyncio
import copy
import json
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock

import httpx
import pytest
from cryptography.fernet import Fernet

from bot import Bot
from core import Engine, Product, SafeError, Store, Supplier

ROOT = Path(__file__).parents[1]


def mapping():
    return copy.deepcopy(json.loads((ROOT / "adapter.json").read_text()))


def live_supplier(tmp_path, row, transport=None):
    catalog = tmp_path / "catalog.json"
    catalog.write_text(json.dumps({"products": [row]}))
    m = mapping()
    return Supplier(False, "confirmed-key", "https://supplier.example/api", m,
                    confirmed=True, transport=transport, catalog_path=catalog,
                    catalog_confirmed=True)


def product(pid="p1", wholesale="10", customer="20", device=1, stock=5):
    return Product(pid, "Plan — 30 days", Decimal(wholesale), stock, "INR",
                   Decimal(customer) if customer is not None else None, device)


def make_pending(store, supplier, p):
    oid = store.create(7, 7, p, 1, supplier.fingerprint(), "source-" + p.pid)
    assert store.transition(oid, "draft", "pending")
    return oid


def test_product_price_contract_and_snapshot():
    p = product()
    assert p.price == Decimal("10")
    assert p.supplier_cost == Decimal("10")
    assert p.selling_price == Decimal("20")
    snap = p.snapshot()
    assert snap["price"] == "10"
    assert snap["supplier_cost"] == "10"
    assert snap["customer_price"] == "20"
    assert snap["device_limit"] == 1
    legacy = Product("old", "Old", Decimal("3"), 1, "INR")
    assert legacy.selling_price == Decimal("3")
    assert legacy.supplier_cost == Decimal("3")


def test_actual_catalog_has_nine_enabled_phantom_rows_and_split_prices():
    data = json.loads((ROOT / "catalog.json").read_text())
    rows = data["products"]
    assert all("price" not in r for r in rows)
    phantom = [r for r in rows if str(r.get("pid")) in {str(x) for x in range(343, 352)}]
    assert len(phantom) == 9
    assert all(r["enabled"] is True for r in phantom)
    assert all(r["enabled"] is False for r in rows if r not in phantom)
    assert all(r.get("device_limit") == 1 for r in phantom)
    assert all("duration" in r["name"].lower() or any(x in r["name"].lower() for x in ("hour", "day")) for r in phantom)
    assert [Decimal(str(r["supplier_cost"])) for r in phantom] == [Decimal(x) for x in ("7", "15", "23", "45", "70", "120", "215", "350", "449")]
    assert [Decimal(str(r["customer_price"])) for r in phantom] == [Decimal(x) for x in ("12", "35", "60", "80", "90", "165", "330", "450", "650")]
    assert "customer_price" not in (mapping()["product_fields"])
    assert mapping()["product_fields"]["price"] == "supplier_cost"


def test_env_example_selects_live_but_requires_local_credentials_and_catalog_confirmation():
    env = (ROOT / ".env.example").read_text()
    assert "DEMO_MODE=false" in env
    assert "API_SCHEMA_CONFIRMED=true" in env
    assert "LIVE_CATALOG_CONFIRMED=false" in env
    assert "PANEL_API_KEY=" in env.splitlines()
    assert "TELEGRAM_BOT_TOKEN=" in env.splitlines()


def test_live_prepared_catalog_still_uses_fake_products_in_demo_mode():
    s = Supplier(True, catalog_path=ROOT / "catalog.json")
    assert [p.pid for p in asyncio.run(s.products())] == ["demo-basic", "demo-pro"]


def test_local_parser_reads_split_prices_and_legacy_fallback(tmp_path):
    m = mapping()
    s = Supplier(True)
    s.mapping = m
    rows = [{"pid": "1", "name": "One — 1 day", "supplier_cost": "7", "customer_price": "12", "stock": None, "currency": "INR", "device_limit": 1},
            {"pid": "2", "name": "Two — 2 days", "supplier_cost": "8", "stock": 3, "currency": "INR"}]
    ps = s.parse_products(rows, local=True)
    assert ps[0].supplier_cost == Decimal("7") and ps[0].selling_price == Decimal("12")
    assert ps[1].selling_price == Decimal("8")


@pytest.mark.parametrize("field,value", [("customer_price", -1), ("customer_price", "NaN"),
                                           ("customer_price", True), ("device_limit", True),
                                           ("device_limit", 0), ("device_limit", -2)])
def test_parser_rejects_invalid_customer_price_and_device_limit(field, value):
    s = Supplier(True)
    row = {"pid": "1", "name": "Plan — 1 day", "supplier_cost": "7", "customer_price": "12",
           "stock": 1, "currency": "INR", "device_limit": 1}
    row[field] = value
    with pytest.raises(SafeError, match="Catalog schema"):
        s.parse_products([row], local=True)


def test_customer_and_admin_preview_have_explicit_price_labels(tmp_path):
    s = Supplier(True)
    st = Store(tmp_path / "db", Fernet.generate_key())
    p = product()
    oid = st.create(7, 7, p, 1, s.fingerprint(), "preview")
    row = st.get(oid)
    b = Bot(st, s, {9}, {7})
    customer = b.preview(row)
    admin = b.preview(row, admin=True)
    assert "20 INR" in customer and "Customer price" in customer
    assert "10 INR" not in customer and "Supplier cost" not in customer
    assert "Customer price" in admin and "Supplier cost" in admin
    assert "10 INR" in admin


def test_products_command_customer_shows_selling_price_device_and_no_cost(tmp_path):
    s = Supplier(True)
    s.products = AsyncMock(return_value=[product()])
    st = Store(tmp_path / "db", Fernet.generate_key())
    b = Bot(st, s, {9}, {7})
    msg = NS(text="/products", reply_text=AsyncMock())
    update = NS(effective_user=NS(id=7), effective_chat=NS(id=7, type="private"), effective_message=msg)
    asyncio.run(b.command(update, NS(args=[])))
    text = msg.reply_text.await_args.args[0]
    assert "20" in text and "1 Device" in text
    assert "10" not in text and "Supplier cost" not in text and "wholesale" not in text.lower()


@pytest.mark.parametrize("change", ["customer", "wholesale", "device"])
def test_engine_expires_when_any_approval_pricing_field_changes(tmp_path, change):
    st = Store(tmp_path / (change + ".db"), Fernet.generate_key())
    original = product()
    current = product(customer="21" if change == "customer" else "20",
                      wholesale="11" if change == "wholesale" else "10",
                      device=2 if change == "device" else 1)
    class Fake:
        demo = True
        def fingerprint(self): return "fp"
        async def products(self): return [current]
        async def order(self, *a): raise AssertionError("no order")
        def validate_quantity(self, q): pass
    s = Fake()
    oid = make_pending(st, s, original)
    with pytest.raises(SafeError, match="changed"):
        asyncio.run(Engine(st, s).approve(oid, 1))
    assert st.get(oid)["state"] == "expired"


def test_healthy_order_payload_and_frozen_quote(tmp_path):
    calls = []
    def handler(request):
        calls.append(json.loads(request.content))
        return httpx.Response(200, json={"status": "success", "license_key": "K", "order_code": "O"})
    row = {"enabled": True, "pid": "1", "name": "Plan — 30 days", "supplier_cost": "7", "customer_price": "12",
           "stock": 5, "currency": "INR", "device_limit": 1}
    s = live_supplier(tmp_path, row, httpx.MockTransport(handler))
    st = Store(tmp_path / "db", Fernet.generate_key())
    p = asyncio.run(s.products())[0]
    oid = make_pending(st, s, p)
    result = asyncio.run(Engine(st, s).approve(oid, 1))
    assert result["state"] == "purchased"
    assert calls[0] == {"key": "confirmed-key", "action": "order", "pid": 1, "quantity": 1, "custom_notes": oid}
    assert "customer_price" not in calls[0] and "supplier_cost" not in calls[0] and "price" not in calls[0]
    quote = json.loads(st.get(oid)["quote"])
    assert quote["price"] == "7" and quote["supplier_cost"] == "7" and quote["customer_price"] == "12"
    assert quote["device_limit"] == 1
