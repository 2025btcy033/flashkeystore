import asyncio
import json
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock

import httpx
import pytest
from cryptography.fernet import Fernet

from bot import Bot
from core import Engine, Product, SafeError, Store, Supplier

ROOT = Path(__file__).parents[1]
MAPPING = json.loads((ROOT / "adapter.json").read_text())


def catalog_file(tmp_path, rows=None):
    path = tmp_path / "catalog.json"
    path.write_text(json.dumps({"products": rows if rows is not None else [{
        "enabled": True, "pid": 7, "name": "Own App", "supplier_cost": "1.00",
        "stock": None, "currency": "INR"
    }]}))
    return path


def live(tmp_path, handler=None, rows=None, confirmed=True):
    transport = httpx.MockTransport(handler or (lambda request: httpx.Response(500)))
    return Supplier(False, "test-key", "https://supplier.example/api", MAPPING,
                    confirmed=confirmed, transport=transport,
                    catalog_path=catalog_file(tmp_path, rows), catalog_confirmed=True)


def run(awaitable):
    return asyncio.run(awaitable)


def test_live_order_is_json_exact_contract_and_returns_key(tmp_path):
    seen = []

    def handler(request):
        seen.append(request)
        assert request.url == "https://supplier.example/api"
        assert request.headers["content-type"].startswith("application/json")
        assert json.loads(request.content) == {
            "key": "test-key", "action": "order", "pid": 7,
            "quantity": 1, "custom_notes": "local-oid"
        }
        return httpx.Response(200, json={"status": "success", "license_key": "LIC-1",
                                         "order_code": "OC-1", "remaining_balance": "9.00"})

    supplier = live(tmp_path, handler)
    assert run(supplier.order("7", 1, "local-oid")) == ("OC-1", ["LIC-1"])
    assert len(seen) == 1


@pytest.mark.parametrize("payload", [
    {"status": "success", "license_key": 123, "order_code": "OC"},
    {"status": "success", "license_key": "LIC"},
])
def test_malformed_order_result_is_safe_and_engine_marks_uncertain(tmp_path, payload):
    def handler(request):
        return httpx.Response(200, json=payload)

    supplier = live(tmp_path, handler)
    store = Store(tmp_path / "db.sqlite3", Fernet.generate_key())
    product = Product("7", "Own App", Decimal("1.00"), None, "INR")
    oid = store.create(10, 10, product, 1, supplier.fingerprint(), "update-1")
    assert store.transition(oid, "draft", "pending")
    with pytest.raises(SafeError, match="uncertain"):
        run(Engine(store, supplier).approve(oid, 99))
    assert store.get(oid)["state"] == "uncertain"


def test_live_quantity_two_rejected_before_post(tmp_path):
    calls = []
    supplier = live(tmp_path, lambda request: calls.append(request) or httpx.Response(200, json={}))
    with pytest.raises(SafeError, match="one returned key"):
        run(supplier.order("7", 2, "oid"))
    assert calls == []


def test_local_catalog_is_authoritative_and_never_posts(tmp_path):
    calls = []
    supplier = live(tmp_path, lambda request: calls.append(request) or httpx.Response(500))
    products = run(supplier.products())
    assert products == [Product("7", "Own App", Decimal("1.00"), None, "INR")]
    assert calls == []


@pytest.mark.parametrize("rows", [
    [],
    [{"enabled": False, "pid": 7, "name": "Own App", "supplier_cost": "1.00", "stock": None, "currency": "INR"}],
    [{"enabled": True, "pid": "", "name": "sample", "supplier_cost": "", "stock": None, "currency": "INR"}],
    [{"enabled": True, "pid": 0, "name": "Own App", "supplier_cost": "1.00", "stock": None, "currency": "INR"}],
    [{"enabled": True, "pid": -2, "name": "Own App", "supplier_cost": "1.00", "stock": None, "currency": "INR"}],
    [{"enabled": True, "pid": 7, "name": "Own App", "supplier_cost": "bogus", "stock": None, "currency": "INR"}],
    [{"enabled": True, "pid": 7, "name": "Own App", "supplier_cost": "1.00", "stock": None, "currency": "INR"},
     {"enabled": True, "pid": 7, "name": "Duplicate", "supplier_cost": "2.00", "stock": None, "currency": "INR"}],
])
def test_live_startup_rejects_unusable_local_catalog(tmp_path, rows):
    with pytest.raises(SafeError):
        live(tmp_path, rows=rows)


def test_live_startup_requires_catalog_confirmation(tmp_path):
    with pytest.raises(SafeError, match="LIVE_CATALOG_CONFIRMED"):
        Supplier(False, "test-key", "https://supplier.example/api", MAPPING,
                 confirmed=True, catalog_path=catalog_file(tmp_path), catalog_confirmed=False)


def test_balance_accepts_statusless_success_and_rejects_bad_values_without_raw_data(tmp_path):
    def ok(request):
        assert json.loads(request.content) == {"key": "test-key", "action": "balance"}
        return httpx.Response(200, json={"balance": "12.50", "currency": "INR"})

    assert run(live(tmp_path, ok).balance()) == (Decimal("12.50"), "INR")

    def bad(request):
        return httpx.Response(200, json={"status": "error", "balance": "private", "currency": "INR"})

    with pytest.raises(SafeError) as exc:
        run(live(tmp_path, bad).balance())
    assert "private" not in str(exc.value)


def test_engine_live_end_to_end_stores_encrypted_key_and_order_code(tmp_path):
    def handler(request):
        return httpx.Response(200, json={"status": "success", "license_key": "SECRET-LIC",
                                         "order_code": "ORDER-42", "remaining_balance": "8.00"})

    supplier = live(tmp_path, handler)
    store = Store(tmp_path / "db.sqlite3", Fernet.generate_key())
    oid = store.create(10, 10, Product("7", "Own App", Decimal("1.00"), None, "INR"),
                       1, supplier.fingerprint(), "source")
    assert store.transition(oid, "draft", "pending")
    result = run(Engine(store, supplier).approve(oid, 99))
    assert result["state"] == "purchased"
    assert result["provider_id"] == "ORDER-42"
    assert store.keys(oid) == ["SECRET-LIC"]
    assert b"SECRET-LIC" not in (tmp_path / "db.sqlite3").read_bytes()


def test_catalog_price_change_expires_quote_without_post(tmp_path):
    calls = []
    supplier = live(tmp_path, lambda request: calls.append(request) or httpx.Response(500))
    store = Store(tmp_path / "db.sqlite3", Fernet.generate_key())
    oid = store.create(10, 10, Product("7", "Own App", Decimal("1.00"), None, "INR"),
                       1, supplier.fingerprint(), "source")
    assert store.transition(oid, "draft", "pending")
    catalog_file(tmp_path, [{"enabled": True, "pid": 7, "name": "Own App", "supplier_cost": "2.00",
                             "stock": None, "currency": "INR"}])
    with pytest.raises(SafeError, match="changed"):
        run(Engine(store, supplier).approve(oid, 99))
    assert store.get(oid)["state"] == "expired"
    assert calls == []


def test_transient_supplier_failure_becomes_uncertain_and_never_reorders(tmp_path):
    calls = []

    def handler(request):
        calls.append(request)
        if len(calls) == 1:
            raise httpx.ReadTimeout("transient")
        return httpx.Response(200, json={"status": "success", "license_key": "L",
                                         "order_code": "O"})

    supplier = live(tmp_path, handler)
    store = Store(tmp_path / "db.sqlite3", Fernet.generate_key())
    oid = store.create(10, 10, Product("7", "Own App", Decimal("1.00"), None, "INR"),
                       1, supplier.fingerprint(), "source")
    store.transition(oid, "draft", "pending")
    with pytest.raises(SafeError, match="uncertain"):
        run(Engine(store, supplier).approve(oid, 99))
    with pytest.raises(SafeError, match="Already handled"):
        run(Engine(store, supplier).approve(oid, 99))
    assert store.get(oid)["state"] == "uncertain"
    assert len(calls) == 1


def update(user=10, command="/orders"):
    return NS(effective_user=NS(id=user), effective_chat=NS(id=user, type="private"),
              effective_message=NS(text=command, reply_text=AsyncMock()), update_id=42)


def test_bot_balance_is_admin_only_and_live_buy_quantity_two_creates_no_draft(tmp_path):
    calls = []
    supplier = live(tmp_path, lambda request: calls.append(request) or httpx.Response(500))
    store = Store(tmp_path / "db.sqlite3", Fernet.generate_key())
    bot = Bot(store, supplier, admins={20}, users={10})
    context = NS(bot=NS(send_document=AsyncMock(), send_message=AsyncMock()), args=["7", "2"])
    user_update = update(10, "/buy 7 2")
    run(bot.command(user_update, context))
    assert "one returned key" in user_update.effective_message.reply_text.await_args.args[0]
    assert store.list_orders(user=10) == []
    assert calls == []

    bot.last.clear()
    context.args = []
    balance_update = update(10, "/balance")
    run(bot.command(balance_update, context))
    assert balance_update.effective_message.reply_text.await_args.args[-1] == "Admin only."
    assert calls == []


def test_snapshot_unknown_stock_does_not_present_numeric_inventory(tmp_path):
    supplier = live(tmp_path)
    product = run(supplier.products())[0]
    assert product.stock is None
    store = Store(tmp_path / "db.sqlite3", Fernet.generate_key())
    oid = store.create(10, 10, product, 2, supplier.fingerprint(), "source")
    assert json.loads(store.get(oid)["quote"])["stock"] is None
