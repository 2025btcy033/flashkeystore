import asyncio
import copy
import json
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock

import httpx
import pytest
from cryptography.fernet import Fernet

from bot import Bot
from core import SafeError, Store, Supplier

ROOT = Path(__file__).resolve().parents[1]
ADMIN = 20
CUSTOMER = 10
KEY = "test-only-live-key"


def update(user=CUSTOMER, chat=CUSTOMER, kind="private", command="/orders", data=None):
    return NS(
        effective_user=NS(id=user), effective_chat=NS(id=chat, type=kind),
        effective_message=NS(text=command, reply_text=AsyncMock()), update_id=42,
        callback_query=NS(
            data=data, answer=AsyncMock(), edit_message_text=AsyncMock()
        ) if data is not None else None,
    )


def call(coro):
    return asyncio.run(coro)


@pytest.fixture
def live_setup(tmp_path):
    source = json.loads((ROOT / "catalog.json").read_text())
    # Tests own a confirmed copy: all nine PHANTOM rows enabled, APKMOD excluded.
    catalog = copy.deepcopy(source)
    for row in catalog["products"]:
        row["enabled"] = bool(row["pid"])
    catalog["products"] = [row for row in catalog["products"] if row["pid"]]
    catalog_path = tmp_path / "catalog.json"
    catalog_path.write_text(json.dumps(catalog))
    mapping = json.loads((ROOT / "adapter.json").read_text())
    requests = []

    async def handler(request):
        body = json.loads(request.content)
        requests.append((request, body))
        assert request.url == httpx.URL("https://supplier.example/api")
        assert body["key"] == KEY
        assert body["action"] == "order"
        return httpx.Response(200, json={
            "status": "success", "order_code": "PROVIDER-1", "license_key": "LIVE-KEY-343"
        })

    transport = httpx.MockTransport(handler)
    supplier = Supplier(
        demo=False, key=KEY, url="https://supplier.example/api", mapping=mapping,
        confirmed=True, transport=transport, catalog_path=catalog_path,
        catalog_confirmed=True,
    )
    store = Store(tmp_path / "store.sqlite3", Fernet.generate_key())
    bot = Bot(store, supplier, admins={ADMIN}, users={CUSTOMER})
    context = NS(
        bot=NS(send_document=AsyncMock(return_value=NS(message_id=901)), send_message=AsyncMock()),
        args=[],
    )
    yield store, supplier, bot, context, requests
    store.db.close()


def run_command(bot, context, user, command, args):
    bot.last.clear()  # avoid burst protection masking independent assertions
    context.args = args
    u = update(user=user, chat=user, command=command)
    call(bot.command(u, context))
    return u


def make_draft(live_setup, user=CUSTOMER):
    store, supplier, bot, context, requests = live_setup
    u = run_command(bot, context, user, "/buy 343 1", ["343", "1"])
    oid = store.list_orders(user=user)[0]["id"]
    return oid, u


def request_approval(live_setup, oid, user=CUSTOMER, chat=None, kind="private"):
    store, supplier, bot, context, requests = live_setup
    chat = user if chat is None else chat
    u = update(user=user, chat=chat, kind=kind, data="request:" + oid)
    call(bot.callback(u, context))
    return u


def test_buy_creates_draft_and_customer_request_makes_pending_without_http(live_setup):
    store, supplier, bot, context, requests = live_setup
    oid, command_update = make_draft(live_setup)
    assert store.get(oid)["state"] == "draft"
    assert not requests
    request_approval(live_setup, oid)
    assert store.get(oid)["state"] == "pending"
    assert not requests
    assert context.bot.send_message.await_count == 1  # admin notification only
    assert command_update.effective_message.reply_text.await_count == 1


def test_customer_forged_approve_is_denied_without_http(live_setup):
    store, supplier, bot, context, requests = live_setup
    oid, _ = make_draft(live_setup)
    request_approval(live_setup, oid)
    forged = update(user=CUSTOMER, chat=CUSTOMER, data="approve:" + oid)
    call(bot.callback(forged, context))
    assert store.get(oid)["state"] == "pending"
    assert not requests
    assert "Admin only." in context.bot.send_message.await_args.args


def test_admin_approve_command_only_previews_pending_without_http(live_setup):
    store, supplier, bot, context, requests = live_setup
    oid, _ = make_draft(live_setup)
    request_approval(live_setup, oid)
    preview = run_command(bot, context, ADMIN, "/approve " + oid, [oid])
    assert store.get(oid)["state"] == "pending"
    assert not requests
    assert "Confirm the supplier order" in preview.effective_message.reply_text.await_args.args[0]


def test_authorized_final_callback_posts_once_delivers_only_original_chat_and_encrypts_keys(live_setup):
    store, supplier, bot, context, requests = live_setup
    oid, _ = make_draft(live_setup)
    request_approval(live_setup, oid)
    # The final approval callback is the only operation that may POST.
    approved = update(user=ADMIN, chat=ADMIN, data="approve:" + oid)
    call(bot.callback(approved, context))
    assert len(requests) == 1
    request, body = requests[0]
    assert request.method == "POST"
    assert body == {"key": KEY, "action": "order", "pid": 343, "quantity": 1, "custom_notes": oid}
    assert store.get(oid)["state"] == "delivered"
    assert store.get(oid)["provider_id"] == "PROVIDER-1"
    assert context.bot.send_document.await_count == 1
    delivery = context.bot.send_document.await_args.kwargs
    assert delivery["chat_id"] == CUSTOMER
    assert delivery["protect_content"] is True
    assert b"LIVE-KEY-343" in delivery["document"].getvalue()
    assert b"LIVE-KEY-343" not in store.get(oid)["keys_cipher"]

    # A repeated approval callback cannot place a second order.
    duplicate = update(user=ADMIN, chat=ADMIN, data="approve:" + oid)
    call(bot.callback(duplicate, context))
    assert len(requests) == 1


def test_revocation_blocks_approval_and_non_private_admin_approval_blocks_post(live_setup):
    store, supplier, bot, context, requests = live_setup
    oid, _ = make_draft(live_setup)
    request_approval(live_setup, oid)
    bot.users.remove(CUSTOMER)
    revoked = update(user=ADMIN, chat=ADMIN, data="approve:" + oid)
    call(bot.callback(revoked, context))
    assert store.get(oid)["state"] == "pending"
    assert not requests

    # A fresh pending order demonstrates the private-chat gate independently.
    bot.users.add(CUSTOMER)
    oid2, _ = make_draft(live_setup)
    request_approval(live_setup, oid2)
    group = update(user=ADMIN, chat=-100, kind="group", data="approve:" + oid2)
    call(bot.callback(group, context))
    assert store.get(oid2)["state"] == "pending"
    assert not requests


def test_reject_cancels_pending_without_purchase(live_setup):
    store, supplier, bot, context, requests = live_setup
    oid, _ = make_draft(live_setup)
    request_approval(live_setup, oid)
    result = run_command(bot, context, ADMIN, "/reject " + oid, [oid])
    assert store.get(oid)["state"] == "canceled"
    assert not requests
    assert result.effective_message.reply_text.await_args.args == ("Order canceled.",)


def test_admin_self_buy_still_requires_request_and_approve(live_setup):
    store, supplier, bot, context, requests = live_setup
    run_command(bot, context, ADMIN, "/buy 343 1", ["343", "1"])
    oid = store.list_orders(user=ADMIN)[0]["id"]
    assert store.get(oid)["state"] == "draft"
    draft_approve = update(user=ADMIN, chat=ADMIN, data="approve:" + oid)
    call(bot.callback(draft_approve, context))
    assert store.get(oid)["state"] == "draft"
    assert not requests
    request_approval(live_setup, oid, user=ADMIN)
    assert store.get(oid)["state"] == "pending"
    final = update(user=ADMIN, chat=ADMIN, data="approve:" + oid)
    call(bot.callback(final, context))
    assert len(requests) == 1


def test_live_startup_requires_credentials_and_catalog_confirmation_before_http(tmp_path, monkeypatch):
    monkeypatch.chdir(ROOT)
    monkeypatch.setenv("DEMO_MODE", "false")
    monkeypatch.setenv("API_SCHEMA_CONFIRMED", "true")
    monkeypatch.setenv("LIVE_CATALOG_CONFIRMED", "false")
    monkeypatch.setenv("API_URL", "https://supplier.example/api")
    monkeypatch.setenv("CATALOG_PATH", str(tmp_path / "catalog.json"))
    monkeypatch.delenv("PANEL_API_KEY", raising=False)
    with pytest.raises(SafeError, match="fresh API key"):
        Supplier.from_env()

    monkeypatch.setenv("PANEL_API_KEY", KEY)
    with pytest.raises(SafeError, match="LIVE_CATALOG_CONFIRMED"):
        Supplier.from_env()
