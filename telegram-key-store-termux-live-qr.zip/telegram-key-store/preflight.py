"""Validate live configuration locally. Never sends a message or an API request."""
import os
import re
import json

from cryptography.fernet import Fernet
from dotenv import load_dotenv

from core import SafeError, Supplier
from payments import PaymentCatalog


def positive_ids(name, required=False):
    values = {int(x.strip()) for x in os.getenv(name, '').split(',') if x.strip()}
    if (required and not values) or any(x <= 0 for x in values):
        raise ValueError('Invalid numeric IDs')
    return values


def check():
    load_dotenv()
    try:
        if os.getenv('DEMO_MODE', '').lower() != 'false':
            raise SafeError('Live preflight needs DEMO_MODE=false. Demo mode is still available with python bot.py.')
        token = os.getenv('TELEGRAM_BOT_TOKEN', '')
        if not re.fullmatch(r'[0-9]+:[A-Za-z0-9_-]{20,}', token):
            raise SafeError('Enter a valid-looking BotFather token locally in TELEGRAM_BOT_TOKEN.')
        positive_ids('ADMIN_IDS', required=True)
        positive_ids('ALLOWED_USER_IDS')
        Fernet(os.getenv('FERNET_KEY', '').encode())
        key = os.getenv('PANEL_API_KEY', '').strip()
        if not key or key.lower().startswith(('your_', 'replace_', 'paste_')):
            raise SafeError('Enter your freshly rotated reseller key locally in PANEL_API_KEY.')
        supplier = Supplier.from_env()
        if supplier.demo or supplier.mapping.get('catalog_source') != 'local':
            raise SafeError('This deployment needs the configured local PHANTOM catalog.')
        products = supplier.local_products()
        if any(p.customer_price is None or p.device_limit is None for p in products):
            raise SafeError('Every enabled plan must define customer_price and device_limit separately from supplier_cost.')
        payments = PaymentCatalog(os.getenv('PAYMENT_MANIFEST_PATH', 'assets/payments/manifest.json'))
        for product in products:
            payments.for_order({'quote': json.dumps(product.snapshot()), 'quantity': 1})
    except SafeError as error:
        print('BLOCKED: ' + str(error))
        return 1
    except Exception:
        # Do not print credentials, exception objects, or raw configuration.
        print('BLOCKED: Check numeric admin/customer IDs, FERNET_KEY, adapter.json and catalog.json locally.')
        return 1
    print(f'READY: {len(products)} enabled plans passed offline live-configuration checks.')
    print('No Telegram or supplier request was made. Token/key validity, current supplier costs and stock are not verified.')
    print('QR payload amounts and image checksums match. Payments need manual bank verification, then separate supplier-order approval.')
    return 0


if __name__ == '__main__':
    raise SystemExit(check())
