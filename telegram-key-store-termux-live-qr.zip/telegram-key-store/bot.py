"""Run one polling worker on a persistent host. See README before live mode."""
import asyncio
import io
import json
import logging
import os
import time

from dotenv import load_dotenv
from decimal import Decimal
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters

from core import Engine, SafeError, Store, Supplier
from payments import PaymentCatalog

load_dotenv()
os.umask(0o077)
# HTTP request URLs contain Telegram tokens. Do not enable library request logs.
logging.basicConfig(level=logging.CRITICAL)


def ids(name):
    try:
        result = {int(x.strip()) for x in os.getenv(name, '').split(',') if x.strip()}
        if any(x <= 0 for x in result):
            raise ValueError()
        return result
    except ValueError:
        raise SafeError(name + ' must contain positive numeric Telegram user IDs.') from None


class Bot:
    def __init__(self, store, supplier, admins, users, payments=None):
        self.store, self.supplier = store, supplier
        self.payments = payments if not supplier.demo else None
        self.engine = Engine(store, supplier, require_payment=self.payments is not None)
        self.admins, self.users = admins, users | admins
        self.last = {}

    def allowed(self, update, admin=False):
        user, chat = update.effective_user, update.effective_chat
        if not user or not chat or chat.type != 'private' or user.id != chat.id:
            return False
        return user.id in (self.admins if admin else self.users)

    def preview(self, row, admin=False):
        q = json.loads(row['quote'])
        mode = ('DEMO — not a valid license' if self.supplier.demo else
                'LIVE — spends reseller balance' if admin else 'LIVE — admin approval required')
        local = not self.supplier.demo and self.supplier.mapping.get('catalog_source') == 'local'
        retail = Decimal(q.get('customer_price', q['price']))
        cost = Decimal(q.get('supplier_cost', q['price']))
        devices = q.get('device_limit')
        admin_cost = (f"\nSupplier cost per key: {cost} {q['currency']}\n"
                      f"Supplier cost total: {cost * row['quantity']} {q['currency']}"
                      if admin else '')
        return (f"{mode}\nOrder: {row['id']}\nCustomer ID: {row['user_id']}\n"
                f"Product: {q['name']}\nPID: {q['pid']}\nQuantity: {row['quantity']}\n"
                f"Customer price per key: {retail} {q['currency']}\n"
                f"Customer total: {retail * row['quantity']} {q['currency']}"
                + (f"\nLimit: {devices} Device(s) per key" if devices is not None else '')
                + admin_cost + '\n'
                +
                f"custom_notes / order reference: {row['id']}\nState: {row['state']}\n"
                'Quote expires 15 minutes after creation. '
                + ('Payment: ' + (self.store.payment(row['id']) or {}).get('status', 'not_requested')
                   + '\nUPI payment requires manual admin verification; no automatic bank verification.'
                   if self.payments else 'No customer payment is collected.')
                + ('\nMANUAL CATALOG: supplier cost and stock are not verified. '
                   'The API has no documented maximum-charge field.' if local and admin else ''))

    def check_payment_asset(self, row):
        asset = self.payments.for_order(row)
        payment = self.store.payment(row['id'])
        if payment and (payment['qr_sha256'] != asset.sha256 or payment['payee_upi'] != asset.payee_upi):
            raise SafeError('Payment QR or payee changed; contact the admin for reconciliation, not a second payment.')
        return asset

    async def show_payment(self, context, row):
        if row['state'] != 'pending':
            raise SafeError('Payment instructions are only available for a pending order. If you already paid, contact the admin.')
        payment = self.store.payment(row['id'])
        if payment and payment['status'] in ('customer_reported', 'verified_manually'):
            raise SafeError('Payment evidence was already submitted. Wait for admin review; do not pay again.')
        if time.time() - row['created'] > 900:
            raise SafeError('Quote expired. Do not pay this QR. If already paid, submit your UTR or screenshot and contact the admin; do not pay again.')
        asset = self.check_payment_asset(row)
        self.store.create_payment(row['id'], asset)
        caption = (f"{json.loads(row['quote'])['name']}\nOrder: {row['id']}\nPay: {asset.amount} {asset.currency}\n"
                   f"Payee: {asset.payee_name}\nUPI ID: {asset.payee_upi}\n"
                   'Payment is awaiting manual verification. Check the payee and amount in your UPI app before paying.\n'
                   f"After payment: /paid {row['id']} YOUR_UTR\n"
                   'Or send a payment screenshot here with the order ID as its caption. '
                   'Do not pay twice; wait for admin verification and supplier approval.')
        with asset.path.open('rb') as image:
            await context.bot.send_document(chat_id=row['chat_id'], document=image,
                                            filename=asset.path.name, caption=caption)

    async def notify_evidence(self, context, row):
        evidence = self.store.payment_evidence(row['id'])
        for admin in self.admins:
            try:
                await context.bot.send_message(chat_id=admin,
                    text=self.preview(row, admin=True) + '\nCustomer-submitted evidence, NOT bank-verified.\nUTR: '
                    + evidence.get('reference', '(screenshot only)') + '\nVerify incoming credit in your bank/UPI app, then /verifypayment ' + row['id'])
                if evidence.get('screenshot_file_id'):
                    sender = context.bot.send_photo if evidence['screenshot_kind'] == 'photo' else context.bot.send_document
                    field = 'photo' if evidence['screenshot_kind'] == 'photo' else 'document'
                    await sender(chat_id=admin, **{field: evidence['screenshot_file_id']},
                                 caption='Unverified customer screenshot. Order: ' + row['id'], protect_content=True)
            except Exception:
                pass  # Persisted evidence remains available with /verifypayment.

    async def receipt(self, update, context):
        if not self.allowed(update):
            return
        message = update.effective_message
        try:
            if not self.payments:
                raise SafeError('Manual QR payments are not enabled in this mode.')
            caption = (message.caption or '').strip()
            if caption:
                row = self.store.get(caption)
            else:
                pending = [r for r in self.store.list_orders(user=update.effective_user.id) if r['state'] == 'pending']
                if len(pending) != 1:
                    raise SafeError('Send the payment screenshot with the exact order ID as its caption.')
                row = pending[0]
            if row['user_id'] != update.effective_user.id:
                raise SafeError('Order not found.')
            self.check_payment_asset(row)
            photos = getattr(message, 'photo', None)
            screenshot = photos[-1] if photos else getattr(message, 'document', None)
            kind = 'photo' if photos else 'document'
            if not screenshot or (kind == 'document' and not (screenshot.mime_type or '').startswith('image/')):
                raise SafeError('Send a photo or image document, not another file type.')
            self.store.report_payment(row['id'], row['user_id'], screenshot_file_id=screenshot.file_id,
                                      screenshot_kind=kind, screenshot_unique_id=screenshot.file_unique_id)
            await message.reply_text('Screenshot submitted for manual review. It is not proof of received payment. Wait for admin approval; do not pay again.')
            await self.notify_evidence(context, self.store.get(row['id']))
        except SafeError as error:
            await message.reply_text(str(error))
        except Exception:
            await message.reply_text('Screenshot submission was not confirmed. Contact the admin; do not pay again.')

    async def command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        message = update.effective_message
        cmd = message.text.split()[0].split('@')[0].lower()
        if cmd == '/id':
            if update.effective_chat.type == 'private':
                await message.reply_text(f'Your Telegram numeric ID: {update.effective_user.id}')
            return
        if not self.allowed(update):
            if update.effective_chat.type == 'private':
                await message.reply_text('This is a private storefront. Ask the owner for access; /id shows your ID.')
            return
        user = update.effective_user.id
        # Basic burst protection, bounded to the configured allowlist.
        if time.monotonic() - self.last.get(user, 0) < 0.8:
            return
        self.last[user] = time.monotonic()
        args = context.args
        try:
            if cmd in ('/start', '/help'):
                await message.reply_text(
                    'Your App Key Store' + (' — DEMO' if self.supplier.demo else ' — LIVE') + '\n\n'
                    '/products [search] — catalog\n/buy PRODUCT_ID QUANTITY — quote\n'
                    '/orders — your history\n/keys ORDER_ID — retrieve purchased keys\n'
                    '/cancel ORDER_ID — cancel a draft or pending request\n/id — your numeric ID\n\n'
                    'An admin must approve every purchase. '
                    + ('UPI QR payments require a UTR or screenshot and manual admin verification. '
                       '/payment ORDER_ID — resend QR\n/paid ORDER_ID UTR — submit reference\n'
                       if self.payments else 'No payments are collected here. ')
                    +
                    'Keys are sent through Telegram, which is not an end-to-end encrypted channel.'
                    + ('\n\nAdmin: /balance, /pending, /verifypayment ORDER_ID, /approve ORDER_ID, /reject ORDER_ID, /retrydelivery ORDER_ID'
                       if user in self.admins else ''))
            elif cmd in ('/payment', '/paid', '/verifypayment'):
                if not self.payments:
                    raise SafeError('Manual QR payments are not enabled in this mode.')
                if cmd == '/verifypayment' and not self.allowed(update, True):
                    raise SafeError('Admin only.')
                if len(args) != (2 if cmd == '/paid' else 1):
                    raise SafeError('Use ' + cmd + ' ORDER_ID' + (' UTR' if cmd == '/paid' else ''))
                row = self.store.get(args[0])
                if cmd != '/verifypayment' and row['user_id'] != user:
                    raise SafeError('Order not found.')
                if cmd == '/payment':
                    await self.show_payment(context, row)
                elif cmd == '/paid':
                    self.check_payment_asset(row)
                    self.store.report_payment(row['id'], user, reference=args[1])
                    await message.reply_text('UTR submitted, NOT automatically verified. Wait for admin verification and approval; do not pay again.')
                    await self.notify_evidence(context, self.store.get(row['id']))
                else:
                    self.check_payment_asset(row)
                    payment = self.store.payment(row['id'])
                    if row['state'] != 'pending' or not payment or payment['status'] != 'customer_reported':
                        raise SafeError('Pending customer-submitted UTR or screenshot required.')
                    await self.notify_evidence(context, row)
                    await message.reply_text(self.preview(row, admin=True) + '\n\nCheck the credited amount, recipient and transaction in your bank/UPI app. '
                        'A screenshot or UTR alone is not payment proof. Marking verified will NOT place a supplier order.',
                        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('I checked the bank: mark payment verified', callback_data='verify:' + row['id'])]]))
            elif cmd == '/balance':
                if not self.allowed(update, True):
                    raise SafeError('Admin only.')
                amount, currency = await self.supplier.balance()
                await message.reply_text(('DEMO wallet (not real): ' if self.supplier.demo else 'Reseller wallet: ')
                                         + f'{amount} {currency}')
            elif cmd == '/products':
                products = await self.supplier.products()
                search = ' '.join(args).casefold()
                products = [p for p in products if search in (p.name + ' ' + p.pid).casefold()]
                if not products:
                    await message.reply_text('No matching products.')
                for p in products[:30]:
                    stock = 'unknown' if p.stock is None else str(p.stock)
                    note = '\nAvailability is not supplier-verified. Admin approval required.' if (
                        not self.supplier.demo and self.supplier.mapping.get('catalog_source') == 'local') else ''
                    devices = f'\nLimit: {p.device_limit} Device(s) per key' if p.device_limit is not None else ''
                    await message.reply_text(f'{p.name}\nID: {p.pid}\nPrice: {p.selling_price} {p.currency} | Stock: {stock}{devices}{note}\n'
                                             f'/buy {p.pid} 1')
                if len(products) > 30:
                    await message.reply_text('Showing the first 30 results. Narrow with /products search-text.')
            elif cmd == '/buy':
                if len(args) != 2 or not args[1].isdigit() or not 1 <= int(args[1]) <= 5:
                    raise SafeError('Use /buy PRODUCT_ID QUANTITY (quantity 1–5).')
                self.supplier.validate_quantity(int(args[1]))
                products = await self.supplier.products()
                p = next((p for p in products if p.pid == args[0]), None)
                if not p:
                    raise SafeError('Product not found; use /products.')
                oid = self.store.create(user, user, p, int(args[1]), self.supplier.fingerprint(), str(update.update_id))
                await message.reply_text(self.preview(self.store.get(oid)), reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton('Request admin approval', callback_data='request:' + oid)],
                    [InlineKeyboardButton('Cancel', callback_data='cancel:' + oid)]]))
            elif cmd in ('/orders', '/pending'):
                if cmd == '/pending' and not self.allowed(update, True):
                    raise SafeError('Admin only.')
                rows = self.store.list_orders(user=user) if cmd == '/orders' else self.store.list_orders(pending=True)
                text = '\n'.join(f"{r['id']} — {r['state']}" for r in rows)
                await message.reply_text(text or 'No orders.')
            elif cmd in ('/keys', '/cancel', '/approve', '/reject', '/retrydelivery'):
                if len(args) != 1:
                    raise SafeError('Use ' + cmd + ' ORDER_ID.')
                if cmd in ('/approve', '/reject', '/retrydelivery') and not self.allowed(update, True):
                    raise SafeError('Admin only.')
                row = self.store.get(args[0])
                if cmd in ('/keys', '/cancel'):
                    if row['user_id'] != user:
                        raise SafeError('Order not found.')
                    if cmd == '/cancel':
                        self.cancel(row)
                        await message.reply_text('Order canceled.')
                    else:
                        await self.deliver(context, row['id'])
                else:
                    if not self.allowed(update, True):
                        raise SafeError('Admin only.')
                    if cmd == '/approve':
                        if row['state'] != 'pending':
                            raise SafeError('Only pending orders can be approved.')
                        if self.payments:
                            self.check_payment_asset(row)
                            if not self.store.payment_verified(row['id']):
                                raise SafeError('Payment is awaiting manual verification. Use /verifypayment ORDER_ID first.')
                        await message.reply_text(self.preview(row, admin=True) + '\n\nConfirm the supplier order below. '
                            'In LIVE mode this may spend your wallet balance. Supplier pricing may change between check and purchase.',
                            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                                'Approve supplier order' if not self.supplier.demo else 'Approve DEMO order',
                                callback_data='approve:' + row['id'])]]))
                    elif cmd == '/reject':
                        self.cancel(row)
                        await message.reply_text('Order canceled.')
                    else:
                        await self.deliver(context, row['id'])
                        await message.reply_text('Stored keys sent to the original customer. No supplier purchase made.')
        except SafeError as error:
            await message.reply_text(str(error))
        except Exception:
            await message.reply_text('Operation failed safely. Check /orders or ask the admin; do not repeat an uncertain purchase.')

    def cancel(self, row):
        payment = self.store.payment(row['id'])
        if payment and payment['status'] in ('customer_reported', 'verified_manually'):
            raise SafeError('Payment was reported for this order. Reconcile it with the admin before cancellation; no automatic refund is available.')
        if row['state'] not in ('draft', 'pending') or not self.store.transition(row['id'], row['state'], 'canceled'):
            raise SafeError('This order cannot be canceled locally. Contact the admin.')

    async def deliver(self, context, oid):
        row = self.store.get(oid)
        if row['user_id'] not in self.users:
            raise SafeError('Customer access was revoked; delivery is blocked.')
        if row['state'] not in ('purchased', 'delivered'):
            raise SafeError('No confirmed purchased keys are ready. Ask the admin for uncertain orders.')
        keys = self.store.keys(oid)
        # One document avoids partial delivery across multiple messages. No local plaintext file.
        payload = ('Order: ' + oid + '\n' + ('DEMO — not valid access keys\n' if self.supplier.demo else '')
                   + '\n'.join(keys) + '\n').encode()
        document = io.BytesIO(payload)
        document.name = 'access-keys-' + oid + '.txt'
        try:
            sent = await context.bot.send_document(chat_id=row['chat_id'], document=document,
                filename=document.name, caption='Your stored access keys. Keep them private.', protect_content=True)
        except Exception:
            raise SafeError('Key delivery was not confirmed. Use /keys ORDER_ID or ask the admin to retry delivery; do not repurchase.') from None
        self.store.delivered(oid, [sent.message_id])

    async def callback(self, update, context):
        query = update.callback_query
        if not self.allowed(update):
            await query.answer('Not authorized.', show_alert=True)
            return
        await query.answer()
        try:
            action, oid = query.data.split(':', 1)
            row = self.store.get(oid)
            if action in ('request', 'cancel'):
                if row['user_id'] != update.effective_user.id:
                    raise SafeError('Order not found.')
                if action == 'cancel':
                    self.cancel(row)
                    await query.edit_message_text('Order canceled.')
                    return
                if time.time() - row['created'] > 900:
                    self.store.transition(oid, 'draft', 'expired')
                    raise SafeError('Quote expired. Create a fresh order.')
                if self.payments:
                    self.payments.for_order(row)  # Fail closed before requesting payment if QR/amount is wrong.
                if not self.store.transition(oid, 'draft', 'pending'):
                    raise SafeError('This request has already been handled; check /orders.')
                await query.edit_message_text('Approval requested. Order: ' + oid)
                if self.payments:
                    asset = self.payments.for_order(self.store.get(oid))
                    self.store.create_payment(oid, asset)
                    try:
                        await self.show_payment(context, self.store.get(oid))
                    except Exception:
                        await context.bot.send_message(row['chat_id'], 'QR delivery was not confirmed. Use /payment ' + oid + ' to retry; do not pay twice.')
                for admin in self.admins:
                    try:
                        await context.bot.send_message(chat_id=admin,
                            text=self.preview(self.store.get(oid), admin=True) + '\n\nReview with /approve ' + oid
                                 + '\nReject with /reject ' + oid)
                    except Exception:
                        # Pending request remains available with /pending even if notification fails.
                        pass
            elif action == 'verify':
                if not self.allowed(update, True):
                    raise SafeError('Admin only.')
                if not self.payments:
                    raise SafeError('Manual payment review is unavailable in this mode.')
                if row['user_id'] not in self.users:
                    raise SafeError('Customer access revoked; reconcile payment manually.')
                self.check_payment_asset(row)
                self.store.verify_payment(oid, update.effective_user.id)
                await query.edit_message_text('Payment marked manually verified by admin. No supplier order sent. Review and approve separately with /approve ' + oid)
                await context.bot.send_message(row['chat_id'], 'Admin marked your payment verified. Waiting for separate supplier-order approval. Order: ' + oid)
            elif action == 'approve':
                if not self.allowed(update, True):
                    raise SafeError('Admin only.')
                if row['user_id'] not in self.users:
                    raise SafeError('Customer access revoked; reject this order.')
                if self.payments:
                    self.check_payment_asset(row)
                await self.engine.approve(oid, update.effective_user.id)
                await query.edit_message_text('Purchase confirmed and stored. Delivering keys for order ' + oid)
                await self.deliver(context, oid)
                await context.bot.send_message(update.effective_chat.id, 'Key delivery confirmed for ' + oid)
            else:
                raise SafeError('Unknown action.')
        except SafeError as error:
            await context.bot.send_message(update.effective_chat.id, str(error))
        except Exception:
            await context.bot.send_message(update.effective_chat.id,
                'Operation interrupted. Check /orders or /pending before doing anything else; never repurchase an uncertain order.')


async def error_handler(update, context):
    # Avoid logging exception objects: network exceptions can contain tokens and raw responses.
    return


def main():
    try:
        token = os.getenv('TELEGRAM_BOT_TOKEN', '')
        admins = ids('ADMIN_IDS')
        encryption = os.getenv('FERNET_KEY', '')
        if not token or not admins or not encryption:
            raise SafeError('Set TELEGRAM_BOT_TOKEN, ADMIN_IDS and FERNET_KEY in .env before starting.')
        supplier = Supplier.from_env()
        store = Store(os.getenv('DB_PATH', 'data/store.sqlite3'), encryption)
        payments = None if supplier.demo else PaymentCatalog(os.getenv('PAYMENT_MANIFEST_PATH', 'assets/payments/manifest.json'))
        bot = Bot(store, supplier, admins, ids('ALLOWED_USER_IDS'), payments=payments)
        app = Application.builder().token(token).concurrent_updates(False).build()
        commands = ['start', 'help', 'id', 'products', 'buy', 'orders', 'keys', 'cancel',
                    'balance', 'pending', 'approve', 'reject', 'retrydelivery', 'payment', 'paid', 'verifypayment']
        app.add_handler(CommandHandler(commands, bot.command))
        app.add_handler(CallbackQueryHandler(bot.callback, pattern=r'^(request|cancel|approve|verify):[a-f0-9]{20}$'))
        app.add_handler(MessageHandler(filters.PHOTO | filters.Document.IMAGE, bot.receipt))
        app.add_error_handler(error_handler)
        print('Starting one polling worker in ' + ('DEMO' if supplier.demo else 'LIVE') + ' mode.', flush=True)
        app.run_polling(allowed_updates=['message', 'callback_query'], drop_pending_updates=False)
    except SafeError as error:
        raise SystemExit(str(error)) from None
    except Exception:
        raise SystemExit('Startup failed. Check local configuration; details suppressed to protect credentials.') from None


if __name__ == '__main__':
    main()
