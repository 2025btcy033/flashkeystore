"""Offline smoke check: no Telegram token, supplier key or network needed."""
import asyncio
import tempfile
from pathlib import Path
from cryptography.fernet import Fernet
from core import Engine, SafeError, Store, Supplier


async def main():
    with tempfile.TemporaryDirectory() as folder:
        store = Store(Path(folder) / 'store.sqlite3', Fernet.generate_key())
        supplier = Supplier(demo=True)
        products = await supplier.products()
        oid = store.create(10001, 10001, products[0], 1, supplier.fingerprint(), 'offline-demo')
        assert store.transition(oid, 'draft', 'pending')
        await Engine(store, supplier).approve(oid, 20002)
        keys = store.keys(oid)
        assert len(keys) == 1 and keys[0].startswith('DEMO-NOT-VALID-')
        assert keys[0].encode() not in store.get(oid)['keys_cipher']
        try:
            await Engine(store, supplier).approve(oid, 20002)
        except SafeError:
            pass
        else:
            raise AssertionError('Duplicate approval was not blocked')
        print('PASS: demo catalog → quote → approval → encrypted keys → duplicate-order protection')
        print('No network requests, Telegram messages or real supplier orders were made.')
        store.db.close()


if __name__ == '__main__':
    asyncio.run(main())
