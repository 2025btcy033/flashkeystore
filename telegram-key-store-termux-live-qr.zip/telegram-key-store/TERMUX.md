# PHANTOM bot: live orders from Termux

This package is prepared for **live supplier orders after admin approval**. PHANTOM PIDs **343–351** are enabled in the catalog, with separate customer prices and wholesale costs. APKMOD is still disabled. No key, token, customer database or test purchase is included.

**Startup stays blocked until you enter a freshly rotated reseller key locally and verify the catalog.** Preparing the package does not connect your account or spend your balance.

## 1. Unpack on your phone

Download `telegram-key-store-termux-live-qr.zip` to Downloads. In your existing Termux:

```bash
pkg install unzip
termux-setup-storage
mkdir -p ~/key-store
unzip -o ~/storage/downloads/telegram-key-store-termux-live-qr.zip -d ~/key-store
cd ~/key-store/telegram-key-store
bash setup_termux.sh
```

Approve Android's storage permission when prompted. Keep the working project in Termux's private home, not shared Downloads. [Official storage instructions](https://wiki.termux.dev/wiki/Termux-setup-storage).

**Updating an existing installation:** first stop the old bot with Ctrl-c. Back up your existing `.env` and `data/` privately, preserving the original `FERNET_KEY`. The ZIP contains source/configuration templates only; it does not overwrite `.env` or `data/`, and the installer preserves existing `.env` values. It does replace the distributed catalog and source files. Do not run old and new polling instances together.

The installer uses Termux's packaged cryptography, creates `.venv-termux` with `--system-site-packages`, and fills a blank encryption-key field without printing it. It does not start the bot or send an API request. Do not upgrade pip with pip inside Termux.

## 2. Fill your local settings

```bash
nano .env
```

Enter these on your phone:

- `TELEGRAM_BOT_TOKEN`: your BotFather token.
- `ADMIN_IDS`: your positive numeric Telegram user ID; comma-separate additional admins if needed.
- `ALLOWED_USER_IDS`: numeric customer IDs. Blank means admins only, not a public shop.
- `PANEL_API_KEY`: **only your newly regenerated reseller key**. Revoke the previously exposed key; never reuse it.

Keep the generated `FERNET_KEY`, or preserve the original one when using an existing database. Never distribute `.env` or your database.

The selected live settings are:

```dotenv
DEMO_MODE=false
API_SCHEMA_CONFIRMED=true
API_URL=https://panelstore.shop/api/v1/index.php
CATALOG_PATH=catalog.json
LIVE_CATALOG_CONFIRMED=false
```

For an existing installation, change these fields manually: the installer deliberately does not overwrite them. `API_SCHEMA_CONFIRMED=true` selects the mapping from your supplied example; it is not a claim of a successful live test.

Open `nano catalog.json` and compare every PHANTOM PID, duration, `supplier_cost`, `customer_price`, currency and one-device limit with your intended settings and supplier panel. The wholesale costs remain unchanged. Once you have checked them, change **`LIVE_CATALOG_CONFIRMED=true` in `.env`**. Leave it false if anything is unresolved. PHANTOM rows are already enabled, so there is no need to bulk-enable the APKMOD placeholder.

## 3. Check offline, then start

```bash
source .venv-termux/bin/activate
python preflight.py
python bot.py
```

`preflight.py` checks local configuration, every enabled plan's QR amount, and PNG file hashes. It sends **no supplier or Telegram requests**, makes no purchase, and cannot verify credentials, current prices/stock or received bank payments. Keep the bundled `assets/payments/` folder intact. Resolve any `BLOCKED` message before starting. Starting the bot connects Telegram polling; it does not automatically place an order or check your supplier balance.

Optional offline regression checks:

```bash
python -m pytest -q
python demo_check.py
```

The tests use fake credentials and mocked responses. Do not run a standalone supplier `buy_key(...)` example as a connectivity test: it can charge your wallet.

## 4. How each purchase works

Every admin and customer must first open the Telegram bot and press Start. Both admin and customer orders follow the same steps:

1. Customer uses `/products` and `/buy 343 1` (or another enabled PID).
2. Customer presses **Request admin approval** and receives the matching cropped QR as a lossless PNG document. Its caption shows the amount and payee. Status is **awaiting manual verification**, not paid. No supplier purchase happens yet.
3. Customer pays using their own UPI app, then sends `/paid ORDER_ID UTR` **or a payment screenshot** as a photo/image document with the exact order ID in its caption. Without a caption, it is attached only to that customer's single pending order. They wait for admin approval; a screenshot or UTR never verifies itself.
4. Admin checks the actual credited payment in their bank/UPI app, then uses `/verifypayment ORDER_ID` and presses **I checked the bank: mark payment verified**. This records a manual decision but does not buy a key.
5. Admin opens `/approve ORDER_ID`, reviews the customer total and supplier cost, then presses **Approve supplier order**. Only this separate confirmation can spend reseller balance.
6. The returned key is encrypted in the local database and sent only to the original customer's private chat.

There is no auto-approval or automatic UPI verification. Customers can use `/payment ORDER_ID` to retry delivery of an unpaid QR. After submitting evidence, do not pay again. All nine supplied QRs were cropped and decode-checked against their originals; embedded amounts match the nine selling prices. No additional QR asset is needed for the current plans. The QR images are not generated or altered payment instructions. `/balance` is an optional admin-only wallet query, not a purchase.

## Limits and recovery

Live quantity is **one key per order** because your API example returns one `license_key`. Payments go directly through the customer's UPI app; there is no payment gateway, automatic bank check or automated refund. Admins must verify the actual credit, not just trust the submitted proof. Payment evidence is encrypted locally and shared only with your configured admins. If a quote expires after payment, reconcile it manually rather than creating another charge. Reported/verified payment orders cannot be canceled casually in the bot. Stock and wholesale costs are manually maintained estimates; the API example has no listing, price-lock, maximum-charge or order-lookup action. Device limits are metadata enforced by your own app.

If a request times out or its result is unclear, do not approve a replacement order. Inspect `/pending` and the supplier panel using the local order reference in `custom_notes`. `/keys ORDER_ID` or admin `/retrydelivery ORDER_ID` can resend a stored key without another supplier purchase. No automatic purchase retries are configured.

This project was tested on Linux, **not your Android phone**, and the supplier contract has not been exercised against your live account. Telegram bot chats are not end-to-end encrypted.

For a detachable process, run inside `tmux new -s keystore`; detach with Ctrl-b then d, and return with `tmux attach -t keystore`. `termux-wake-lock` may help, but Android can still kill Termux. Keep internet access and exactly one polling worker; this is not guaranteed 24/7 hosting or reboot persistence.

## Official Termux references

[Termux guidance](https://wiki.termux.dev/wiki/Main_Page), [storage permissions](https://wiki.termux.dev/wiki/Termux-setup-storage), [native cryptography package](https://github.com/termux/termux-packages/tree/master/packages/python-cryptography), and [Python package definition](https://raw.githubusercontent.com/termux/termux-packages/master/packages/python/build.sh), which lists pip and ensurepip wheels separately. The installer uses `pkg` for these packages rather than compiling cryptography with pip.
