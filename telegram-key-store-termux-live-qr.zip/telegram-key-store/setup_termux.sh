#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
umask 077

if [[ -z "${PREFIX:-}" || "${PREFIX}" != /data/data/com.termux/files/usr* ]]; then
  printf '%s\n' 'ERROR: run this script inside Termux (PREFIX is not a Termux prefix).' >&2
  exit 1
fi

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
cd "$SCRIPT_DIR"

command -v pkg >/dev/null 2>&1 || {
  printf '%s\n' 'ERROR: pkg was not found; use a normal Termux installation.' >&2
  exit 1
}
[[ -f requirements-termux.txt ]] || {
  printf '%s\n' 'ERROR: requirements-termux.txt is missing from this project.' >&2
  exit 1
}
[[ -f .env.example ]] || {
  printf '%s\n' 'ERROR: .env.example is missing from this project.' >&2
  exit 1
}

# Do not run a blanket distribution upgrade. Install only the required packages.
pkg install -y python python-pip python-ensurepip-wheels python-cryptography unzip nano tmux

python -m venv --system-site-packages .venv-termux
# shellcheck disable=SC1091
source .venv-termux/bin/activate
pip install -r requirements-termux.txt

if [[ ! -e .env ]]; then
  cp .env.example .env
fi
chmod 600 .env

# Fill only an empty FERNET_KEY; never print the generated secret.
python - <<'PY'
from pathlib import Path
from cryptography.fernet import Fernet

path = Path('.env')
text = path.read_text()
if text and not text.endswith('\n'):
    text += '\n'
lines = text.splitlines(keepends=True)
found = False
changed = False
out = []
for line in lines:
    if line.startswith('FERNET_KEY='):
        found = True
        if line.rstrip('\r\n').split('=', 1)[1].strip() == '':
            ending = line[len(line.rstrip('\r\n')):]
            line = 'FERNET_KEY=' + Fernet.generate_key().decode() + (ending or '\n')
            changed = True
    out.append(line)
if not found:
    out.append('FERNET_KEY=' + Fernet.generate_key().decode() + '\n')
    changed = True
if changed:
    path.write_text(''.join(out))
path.chmod(0o600)
PY

printf '%s\n' 'Termux setup complete. Edit .env before running checks or the bot.'
